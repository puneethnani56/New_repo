import os
import sys
from databaselib import exec_sql
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

DATE_FORMAT = "%d/%b/%Y"

def get_current_year_month(date_val: str) -> tuple:
    """
    Returns the current year and month from the given date string.

    Args:
        date_val (str): The date string in the format '%d/%b/%Y'.

    Returns:
        tuple: A tuple containing the current year and month.
    """
    date_val = datetime.strptime(date_val, DATE_FORMAT).date()
    curr_year = date_val.year
    curr_month = date_val.month

    return curr_year, curr_month

def get_previous_year_month(date_val: str) -> tuple:
    """
    Returns the previous year and month from the given date string.

    Args:
        date_val (str): The date string in the format '%d/%b/%Y'.

    Returns:
        tuple: A tuple containing the previous year and month.
    """
    date_val = datetime.strptime(date_val, DATE_FORMAT).date()
    prev_date = (date_val - relativedelta(months=1))
    prev_year = prev_date.year
    prev_month = prev_date.month

    return prev_year, prev_month


def is_weekend_day(date_val: datetime.date) -> bool:
    """
    Checks if the given date is a weekend day.

    Args:
        date_val (datetime.date): The date to check.

    Example:
        0 = Monday and 6 = Sunday

    Returns:
        bool: True if the date is a weekend day, False otherwise.
    """
    return date_val.weekday() >= 5

def is_non_working_day(date_val: datetime.date, holiday_list: list) -> bool:
    """
    Checks if the given date is a non-working day.

    Args:
        date_val (datetime.date): The date to check.
        holiday_list (list): A list of holiday dates.

    Returns:
        bool: True if the date is a non-working day, False otherwise.
    """
    return date_val in holiday_list

def _roll_back_to_business_day(date_val, holiday_date_list: list) -> str:
    """
    Subtract 1 day at a time from date_val until a working day (not weekend,
    not holiday) is found. Returns the result formatted as 'YYYYMMDD'.
    Accepts either datetime or date objects.
    """
    while True:
        if not is_weekend_day(date_val) and not is_non_working_day(date_val, holiday_date_list):
            # datetime objects need .date() before strftime to match original behaviour
            if isinstance(date_val, datetime):
                return date_val.date().strftime('%Y%m%d')
            return date_val.strftime('%Y%m%d')
        date_val -= timedelta(days=1)


def _roll_forward_to_business_day(date_val, holiday_date_list: list) -> str:
    """
    Add 1 day at a time to date_val until a working day (not weekend,
    not holiday) is found. Returns the result formatted as 'YYYYMMDD'.
    """
    # If the next business day is a weekend, add 1 day, until we get the Monday date as next business_date
    while True:
        if not is_weekend_day(date_val) and not is_non_working_day(date_val, holiday_date_list):
            return date_val.strftime('%Y%m%d')
        date_val += timedelta(days=1)


def _calc_dates_no_existing(date_param: str, holiday_date_list: list) -> tuple:
    """
    Calculate previous, current, and next business dates when date_exists == 'N'.
    Rolls backward from date_param to find current business date, then derives
    previous (roll back 1 more) and next (roll forward from current).
    Returns (previous_business_date, current_business_date, next_business_date).
    """
    # Parse the string into a datetime object - current_business_date
    current_business_date = datetime.strptime(date_param, DATE_FORMAT)
    current_business_date -= timedelta(days=1)
    current_business_date = _roll_back_to_business_day(current_business_date, holiday_date_list)

    # Parse the string into a datetime object - previous_business_date
    previous_business_date = datetime.strptime(current_business_date, '%Y%m%d').date() - timedelta(days=1)
    previous_business_date = _roll_back_to_business_day(previous_business_date, holiday_date_list)

    # Get the next business date - next_business_date
    next_business_date = datetime.strptime(current_business_date, '%Y%m%d').date() + timedelta(days=1)
    next_business_date = _roll_forward_to_business_day(next_business_date, holiday_date_list)

    return previous_business_date, current_business_date, next_business_date


def _calc_dates_existing(date_param: str, holiday_date_list: list) -> str:
    """
    Calculate next business date when date_exists == 'Y'.
    Uses date_param as the current business date and rolls forward to find next.
    Returns next_business_date as 'YYYYMMDD'.
    """
    # Parse the string into a datetime object - current_business_date
    current_business_date = datetime.strptime(date_param, DATE_FORMAT)
    current_business_date = current_business_date.strftime('%Y%m%d')

    # Get the next business date - next_business_date
    next_business_date = datetime.strptime(current_business_date, '%Y%m%d').date() + timedelta(days=1)
    next_business_date = _roll_forward_to_business_day(next_business_date, holiday_date_list)

    return next_business_date


def roll_srcsys_business_date(date_param: str, src_sys: str, date_exists: str) -> str | tuple:
    """
    Returns the previous working day from the given date string.

    Args:
        date_param (str): The date string in the format '%d/%b/%Y'.
        src_sys (str): Application name as src_sys from app_config table.

    Returns:
        str: The previous working day in the format 'YYYYMMDD'.
    """
    current_year, current_month = get_current_year_month(date_param)

    _, previous_month = get_previous_year_month(date_param)

    holiday_dates = exec_sql(f"SELECT holiday_dt FROM app_calendar WHERE app_name = (select app_name from app_config where app_description = '{src_sys}') AND year = {current_year} AND month IN ({current_month}, {previous_month}) OR ( {current_month} = 1 AND (year = {current_year} AND month = 1 OR year = {current_year} - 1 AND month = 12))")

    date_list = [rec[0].strftime('%Y-%m-%d') for rec in holiday_dates]
    holiday_date_list = [datetime.strptime(date, '%Y-%m-%d').date() for date in date_list]

    if date_exists == 'N':
        return _calc_dates_no_existing(date_param, holiday_date_list)

    elif date_exists == 'Y':
        return _calc_dates_existing(date_param, holiday_date_list)

def roll_unisrc_business_date(date_param: str) -> tuple:
    """
    Returns the previous, current, and next business dates from the given date string.

    Args:
        date_val (str): The date string in the format '%d/%b/%Y'.

    Returns:
        tuple: A tuple containing the previous, current, and next business dates in the format 'YYYYMMDD'.
    """
    date_val_dt = datetime.strptime(date_param, DATE_FORMAT).date()

    # Subtract 1 day to get current business_date
    current_business_date = date_val_dt - timedelta(days=1)

    # If the current business_date is a weekend, subtract 1 day, until we get the Friday date as current business_date
    while current_business_date.weekday() >= 5:
        current_business_date -= timedelta(days=1)

    current_business_date = current_business_date.strftime('%Y%m%d')

    # Get the previous business date
    previous_business_date_dt = datetime.strptime(current_business_date, '%Y%m%d').date() - timedelta(days=1)

    # If the previous business day is a weekend, subtract 1 day, until we get the Friday date as previous business_date
    while previous_business_date_dt.weekday() >= 5:
        previous_business_date_dt -= timedelta(days=1)

    previous_business_date = previous_business_date_dt.strftime('%Y%m%d')

    # Get the next business date
    next_business_date_dt = datetime.strptime(current_business_date, '%Y%m%d').date() + timedelta(days=1)

    # If the next business day is a weekend, add 1 day, until we get the Monday date as next business_date
    while next_business_date_dt.weekday() >= 5:
        next_business_date_dt += timedelta(days=1)

    next_business_date = next_business_date_dt.strftime('%Y%m%d')

    return previous_business_date, current_business_date, next_business_date

def convert_date_ddmmyyyy(date_str: str) -> str:
    date_obj = datetime.strptime(date_str, '%Y%m%d')
    date_string = date_obj.strftime('%d%m%Y')

    return date_string

def adjust_date_format(date_str: str, source_fmt: str, dest_fmt: str) -> tuple[str, str]:
    try:
        if len(dest_fmt) > 6:
            date_str = date_str + datetime.now().strftime('%H%M%S')
            source_fmt = source_fmt+'%H%M%S'

        return date_str, source_fmt

    except ValueError as e:
        raise RuntimeError(f"Exception occurred on adjust_date_format from get_business_date : {e}")

def convert_to_date_format(date_str: str, dest_date_format: str, add_days: int = 0) -> str:
    try:
        adjusted_date_str, src_date_format = adjust_date_format(date_str, '%Y%m%d', dest_date_format)

        date_object =  datetime.strptime(adjusted_date_str, src_date_format)

        if add_days > 0:
            date_object += timedelta(days=int(add_days))

        date_string = date_object.strftime(dest_date_format)

        return date_string
    except ValueError as e:
        raise RuntimeError(f"Exception occurred on convert_to_date_format from get_business_date : {e}")
