import os
import shutil
import sys
import subprocess
import pathlib
import argparse
from functools import wraps

UNISRC_NAS_SERVER = "s|<UNISRC_NAS_SHARE_SERVER>|na8101pic00901.xmp.net.intra|g"
UNIDATA_NAS_SERVER = "s|<UNIDATA_NAS_SHARE_SERVER>|na8201pic00801.xmp.net.intra|g"
UNISRC_ARTIFACTORY_REPO = "s|<UNISRC_ARTIFACTORY_REPO>|unidata-docker-local-dev|g"

class ReleaseDeployment(object) :

  def __init__(self, date: str, branch_name: str, release_repo: bool):
    self.__release_date = date
    self.__branch_name = branch_name
    self.__release_repo = release_repo
    self.__manifest_file = self.__release_date +".mf"
    self.__tar_file = "unisrc_"+self.__release_date +".tar"
    self.__release_folder = self.__release_date
    self.__unisrc_nas_folder = "/data/unisrc_nas"
    self.__release_tar_dir = "/data/unisrc_nas/releases"
    self.__release_rollback_dir = "/data/unisrc_nas/releases/rollback"
    self.__valid_category = ['DB', 'DEFAULT', 'DAG', 'DAG_TEMPLATE', 'INSTALLER_SQL', 'INSTALLER_ROLLBACK', 'INSTALLER_SH', 'AUTOSYS', 'SPARK', 'PYTHON', 'TOOLS']
    self.__env_map = {'DEV1': 'D', 'DEV2': 'D', 'UAT2': 'D', 'STG': 'S', 'PRD': 'P'}
    print(self.__release_date)
    print(self.__manifest_file)
    self.__env_type = self._get_environment()

  def _get_environment(self):
    host_name = os.uname()[1]
    if host_name == 'narvlii21331':
      return 'DEV1'
    elif host_name == 'narvlii21771':
      return 'DEV2'
    elif host_name == 'narvlii21770':
      return 'UAT2'
    elif host_name == 'narvlii26156':
      return 'STG'
    elif host_name == 'narvlii26157':
      return 'PRD'
    else:
      print(f"Host : {host_name} not configured. exiting.")
      sys.exit(1)
  
  def get_function_name(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        print(f"Starting {func.__name__}...")
        return func(*args, **kwargs)
    return wrapper
    
  @get_function_name
  def __validate_category_list(self) -> bool:
    if set(self.__installer_category).issubset(set(self.__valid_category)) :
      return True
    else :
      items_not_in_list2 = [item for item in self.__installer_category if item not in self.__valid_category]
      if items_not_in_list2 :
        print(f"Category is not found in the manifesst file : {items_not_in_list2}")
        return False
      else :
        return True

  @get_function_name
  def _execute_sql_file(self):
    try:
      sql_cmd = f". /data/unisrc_nas/unisrc_env_setup; unisrcsqlfile {self.__file}"
      print(f"Executing sql command : {sql_cmd}")
      result = subprocess.call(["bash", "-c", sql_cmd], stdin=subprocess.DEVNULL)
      # integer object has no attribute returncode
      if result != 0:
          print(f"Command : {sql_cmd} failed with return code {result}.")
          raise RuntimeError(f"result code is {result} while executing {sql_cmd}")
    except (subprocess.CalledProcessError, ValueError, AttributeError) as err:
      error_string = f"Something has gone wrong on subprocess - {str(err)}"
      print(error_string)
      sys.exit(1)
    except Exception as e:
      error_string = f"Something has gone wrong in _execute_sql_file - {str(e)}"
      print(error_string)
      sys.exit(1)

  @get_function_name
  def _subs_autosys_airflow_url(self):
    try:
      if self.__env_type == 'DEV1':
        replace_val = ["sed", "-i", "s|<AIRFLOW_UI_URL>|https://unidata-k8s-dev1.dev.echonet/airflow|g", f"{self.__file}"]
      elif self.__env_type == 'DEV2':
        replace_val = ["sed", "-i", "s|<AIRFLOW_UI_URL>|https://unidata-k8s-dev2.dev.echonet/airflow|g", f"{self.__file}"]
      elif self.__env_type == 'UAT2':
        replace_val = ["sed", "-i", "s|<AIRFLOW_UI_URL>|https://unidata-k8s-uat2.dev.echonet/airflow|g", f"{self.__file}"]
      elif self.__env_type == 'STG':
        replace_val = ["sed", "-i", "s|<AIRFLOW_UI_URL>|https://unidata.staging.echonet/airflow|g", f"{self.__file}"]
      elif self.__env_type == 'PRD':
        replace_val = ["sed", "-i", "s|<AIRFLOW_UI_URL>|https://unidata.cib.echonet/airflow/|g", f"{self.__file}"]

      result = subprocess.run(replace_val, stdin=subprocess.DEVNULL)
      if result.returncode != 0:
         print(f"Command : {replace_val} failed with return code {result.returncode}.")
         raise RuntimeError(f"result code is {result.returncode} with return as {result} while executing {replace_val}")

    except Exception as e:
      error_string = f"Something has gone wrong - {str(e)}"
      print(error_string)
      sys.exit(1)

  @get_function_name
  def _subs_autosys_jil_values(self):
    try:
      replace_val = ["sed", "-i", "-e", f"s|<ENV_PREFIX>|{self.__env_map.get(self.__env_type)}|g", "-e", f"s|<AUTOSYS_ENV_NAME>|{self.__env_type}|g", "-e", f"s|<AUTOSYS_SERVER_NAME>|{self.__env_type}|g", f"{self.__file}"]

      result = subprocess.run(replace_val, stdin=subprocess.DEVNULL)
      if result.returncode != 0:
         print(f"Command : {replace_val} failed with return code {result.returncode}.")
         raise RuntimeError(f"result code is {result.returncode} with return as {result} while executing {replace_val}")

    except Exception as e:
      error_string = f"Something has gone wrong - {str(e)}"
      print(error_string)
      sys.exit(1)

  @get_function_name
  def _subs_dag_values(self):
    try:
      if not self.__release_repo:
        artif_repo_val = 'unidata-docker-local-dev' if self._get_environment() != 'PRD' else 'unidata-docker-local-release'
        replace_val = ["sed", "-i", "-e", f"s|<UNISRC_ARTIFACTORY_REPO>|{artif_repo_val}|g", f"{self.__file}"]
      else:
        replace_val = ["sed", "-i", "-e", "s|<UNISRC_ARTIFACTORY_REPO>|unidata-docker-local-release|g", f"{self.__file}"]

      result = subprocess.run(replace_val, stdin=subprocess.DEVNULL)
      if result.returncode != 0:
         print(f"Command : {replace_val} failed with return code {result.returncode}.")
         raise RuntimeError(f"result code is {result.returncode} with return as {result} while executing {replace_val}")

    except Exception as e:
      error_string = f"Something has gone wrong - {str(e)}"
      print(error_string)
      sys.exit(1)

  @get_function_name
  def _subs_dag_template(self):
    try:
      if self.__env_type == 'DEV1':
        replace_val = ["sed", "-i", "-e", "s|<UNISRC_NAS_SHARE_SERVER_PATH>|/na8101pfv00904/unisrc_nas_k8s_dev1|g", "-e", UNISRC_NAS_SERVER, "-e", "s|<UNIDATA_NAS_SHARE_SERVER_PATH>|/na8201pfv00805/unidata_nfs_dev1|g", "-e", UNIDATA_NAS_SERVER, "-e", UNISRC_ARTIFACTORY_REPO, f"{self.__file}"]
      elif self.__env_type == 'DEV2':
        replace_val = ["sed", "-i", "-e", "s|<UNISRC_NAS_SHARE_SERVER_PATH>|/na8201pfv00a02/unisrc_nas_k8s_dev2|g", "-e", "s|<UNISRC_NAS_SHARE_SERVER>|na8201pic00a01.xmp.net.intra|g", "-e", "s|<UNIDATA_NAS_SHARE_SERVER_PATH>|/na8201pfv00805/unidata_nfs_dev1|g", "-e", UNIDATA_NAS_SERVER, "-e", UNISRC_ARTIFACTORY_REPO, f"{self.__file}"]
      elif self.__env_type == 'UAT2':
        replace_val = ["sed", "-i", "-e", "s|<UNISRC_NAS_SHARE_SERVER_PATH>|/na8101pfv00904/unisrc_nas_k8s_uat2|g", "-e", UNISRC_NAS_SERVER, "-e", "s|<UNIDATA_NAS_SHARE_SERVER_PATH>|/na8201pfv00804/unidata_nfs_uat1|g", "-e", UNIDATA_NAS_SERVER, "-e", UNISRC_ARTIFACTORY_REPO, f"{self.__file}"]
      elif self.__env_type == 'STG':
        replace_val = ["sed", "-i", "-e", "s|<UNISRC_NAS_SHARE_SERVER_PATH>|/na8101pfv00904/unisrc_nas_k8s_stg|g", "-e", UNISRC_NAS_SERVER, "-e", "s|<UNIDATA_NAS_SHARE_SERVER_PATH>|/na8101pfv00703/unidata_nfsfile_stg|g", "-e", "s|<UNIDATA_NAS_SHARE_SERVER>|na8101pic00701.xmp.net.intra|g", "-e", UNISRC_ARTIFACTORY_REPO, f"{self.__file}"]
      elif self.__env_type == 'PRD':
        replace_val = ["sed", "-i", "-e", "s|<UNISRC_NAS_SHARE_SERVER_PATH>|/na8101pfv00904/unisrc_nas_k8s_prd|g", "-e", UNISRC_NAS_SERVER, "-e", "s|<UNIDATA_NAS_SHARE_SERVER_PATH>|/vol/ihcdata2/cib_landing|g", "-e", "s|<UNIDATA_NAS_SHARE_SERVER>|nycv00054044.us.net.intra|g", "-e", "s|<UNISRC_ARTIFACTORY_REPO>|unidata-docker-local-release|g", f"{self.__file}"]
      
      result = subprocess.run(replace_val, stdin=subprocess.DEVNULL)
      if result.returncode != 0:
         print(f"Command : {replace_val} failed with return code {result.returncode}.")
         raise RuntimeError(f"result code is {result.returncode} with return as {result} while executing {replace_val}")

    except Exception as e:
      error_string = f"Something has gone wrong - {str(e)}"
      print(error_string)
      sys.exit(1)

  @get_function_name
  def _install_db_sql(self, file: str):
    """Handle DB and INSTALLER_SQL category: rollback backup, execute sql, copy to unisrc_nas."""
    appl_file_path = '/data/unisrc_nas/unisrc/'
    self._rollback_backup(self.__file_basename, appl_file_path, file)

    # execute the .sql file
    self._execute_sql_file()

    # copying release file to unisrc_nas path
    self._copy_source_to_unisrc(self.__file, file)

  @get_function_name
  def _install_installer_sh(self, file: str):
    """Handle INSTALLER_SH category: rollback backup, copy file, copy to unisrc_nas."""
    etl_scripts_path = '/data/Unidata/ETL/Scripts/'
    # taking backup for rollback
    appl_file_path = etl_scripts_path
    self._rollback_backup(self.__file_basename, appl_file_path, file)

    shutil.copy(os.path.join(self.__release_tar_dir, self.__release_folder, self.__file), appl_file_path)

    # copying release file to unisrc_nas path
    self._copy_source_to_unisrc(self.__file, file)

  @get_function_name
  def _install_autosys(self, file: str):
    """Handle AUTOSYS category: dispatch by file suffix (JIL/PY/SH), copy to unisrc_nas."""
    etl_scripts_path = '/data/Unidata/ETL/Scripts/'
    file_path = pathlib.Path(os.path.join(self.__release_tar_dir, self.__release_folder, self.__file))
    print(f"file_path : {file_path}, suffix : {str(file_path.suffix).upper()}")

    if str(file_path.suffix).upper().strip('.') == 'JIL':
      print(f"\033[33mRollback not needed for {self.__category} category JIL files. SKIP\033[0m")

      print("Replacing Autosys JIL default strings...")
      self._subs_autosys_jil_values()

      print(f"No need to move Autosys file with replaced values : {self.__file}")

    elif str(file_path.suffix).upper().strip('.') == 'PY':
      # taking backup for rollback
      appl_file_path = '/data/UNIDATA_NAS_SHARE_NFSETLK8/dags/autosys/'
      self._rollback_backup(self.__file_basename, appl_file_path, file)

      print("Replacing Autosys PY Airflow URL default strings...")
      self._subs_autosys_airflow_url()

      print(f"Moving Autosys file : {self.__file}")
      shutil.copy(os.path.join(self.__release_tar_dir, self.__release_folder, self.__file), appl_file_path)

    elif str(file_path.suffix).upper().strip('.') == 'SH':
      # taking backup for rollback
      appl_file_path = etl_scripts_path
      self._rollback_backup(self.__file_basename, appl_file_path, file)

      print(f"Moving Autosys file : {self.__file}")
      shutil.copy(os.path.join(self.__release_tar_dir, self.__release_folder, self.__file), appl_file_path)

    # copying release file to unisrc_nas path
    self._copy_source_to_unisrc(self.__file, file)

  @get_function_name
  def _install_spark_python(self, file: str):
    """Handle SPARK, PYTHON, SHELL category: rollback backup, copy file, copy to unisrc_nas."""
    etl_scripts_path = '/data/Unidata/ETL/Scripts/'
    # taking backup for rollback
    appl_file_path = etl_scripts_path
    self._rollback_backup(self.__file_basename, appl_file_path, file)
    shutil.copy(os.path.join(self.__release_tar_dir, self.__release_folder, self.__file), appl_file_path)

    # copying release file to unisrc_nas path
    self._copy_source_to_unisrc(self.__file, file)

  @get_function_name
  def _install_dag(self, file: str):
    """Handle DAG category: corelib path or regular dags path, rollback, subs, copy, copy to unisrc_nas."""
    print(f"Moving DAG file : {self.__file}")
    if 'corelib' in self.__file:
      corelib_path = '/data/UNIDATA_NAS_SHARE_NFSETLK8/dags/corelib'

      # taking backup for rollback
      self._rollback_backup(self.__file_basename, corelib_path, file)

      if not os.path.exists(corelib_path):
        try:
          os.mkdir(corelib_path)

          os.chmod(corelib_path, 0o777)
        except Exception as e:
          print(f"Something has gone wrong creating/set permission directory : {corelib_path} with exception : {e}")
          raise RuntimeError(f"Something has gone wrong creating/set permission directory : {corelib_path} with exception : {e}")
      shutil.copy(os.path.join(self.__release_tar_dir, self.__release_folder, self.__file), '/data/UNIDATA_NAS_SHARE_NFSETLK8/dags/corelib')
    else:
      # taking backup for rollback
      appl_file_path = '/data/UNIDATA_NAS_SHARE_NFSETLK8/dags/'
      self._rollback_backup(self.__file_basename, appl_file_path, file, 'Y')

      print("Replacing DAG default strings...")
      self._subs_dag_values()

      shutil.copy(os.path.join(self.__release_tar_dir, self.__release_folder, self.__file), appl_file_path)

    # copying release file to unisrc_nas path
    self._copy_source_to_unisrc(self.__file, file)

  @get_function_name
  def _install_dag_template(self, file: str):
    """Handle DAG_TEMPLATE category: rollback backup, subs dag template, copy file, copy to unisrc_nas."""
    # taking backup for rollback
    appl_file_path = '/data/UNIDATA_NAS_SHARE_NFSETLK8/dags/templates/'
    self._rollback_backup(self.__file_basename, appl_file_path, file, 'Y')

    print("Replacing DAG Template default strings...")
    self._subs_dag_template()

    print(f"Moving DAG Template : {self.__file}")
    shutil.copy(os.path.join(self.__release_tar_dir, self.__release_folder, self.__file), appl_file_path)

    # copying release file to unisrc_nas path
    self._copy_source_to_unisrc(self.__file, file)

  @get_function_name
  def _install_tools(self, file: str):
    """Handle TOOLS category: rollback backup, create dir if needed, copy file, copy to unisrc_nas."""
    # taking backup for rollback
    appl_file_path = '/data/unisrc_nas/unisrc/tools'
    self._rollback_backup(self.__file_basename, appl_file_path, file)

    if not os.path.exists(appl_file_path):
      if self._create_nested_directories(os.path.join('/data/unisrc_nas/'), str('unisrc/tools').split("/")):
        print(f"Directory {appl_file_path} created")
      else:
        print(f"Error creating directory : {appl_file_path}")

    print(f"Moving release script : {self.__file}")
    shutil.copy(os.path.join(self.__release_tar_dir, self.__release_folder, self.__file), appl_file_path)

    # copying release file to unisrc_nas path
    self._copy_source_to_unisrc(self.__file, file)

  @get_function_name
  def __copy_and_installer(self):
    etl_scripts_path = '/data/Unidata/ETL/Scripts/'
    try:
      for category, files in self.__manifest_data.items():
        for file in files:
          self.__category = category
          self.__file = os.path.join(self.__release_tar_dir, self.__release_folder, file)
          self.__file_basename = os.path.basename(self.__file)

          if (self.__category in ["DB", "INSTALLER_SQL"]):
            self._install_db_sql(file)
          elif (self.__category == "INSTALLER_SH"):
            self._install_installer_sh(file)
          elif (self.__category == "AUTOSYS"):
            self._install_autosys(file)
          elif (self.__category in ["SPARK", "PYTHON", "SHELL"]):
            self._install_spark_python(file)
          elif (self.__category == "DAG"):
            self._install_dag(file)
          elif (self.__category == "DAG_TEMPLATE"):
            self._install_dag_template(file)
          elif (self.__category == "TOOLS"):
            self._install_tools(file)
          elif (self.__category == "DEFAULT"):
            # on default move to respective directory, no execution
            # copying release file to unisrc_nas path
            self._copy_source_to_unisrc(self.__file, file)
          else:
            print(f"Unsupported category {self.__category}")
    except Exception as e:
      error_string = f"Something has gone wrong in {__name__} - {str(e)}"
      print(error_string)
      sys.exit(1)

  @get_function_name
  def _read_manifest_file(self):
    try:
      with open(os.path.join(self.__release_tar_dir, self.__release_folder, self.__manifest_file), 'r') as f:
        lines = f.readlines()
        self.__manifest_data = {}
        self.__installer_category = []
        for line in lines:
          if str(line).strip():
            category, file = line.strip().split(' ', 1)
            if category not in self.__manifest_data:
              self.__manifest_data[category] = []
            self.__manifest_data[category].append(file)
            self.__installer_category.append(category)

        print(f"manifest category: {self.__manifest_data.keys()}")
        if self.__validate_category_list() == False:
          sys.exit(1)
        else:
          print("copy files and running installer ")
          self.__copy_and_installer()

          print("installation completed")

    except Exception as e:
      error_string = "Something has gone wrong - " + str(e)
      print(error_string)
      sys.exit(1)

  @get_function_name
  def _create_dir(self, target_folder):
      try:
        if not (os.path.exists(target_folder)):
          print(f"Creating {target_folder} directory...")
          os.mkdir(target_folder)
        folder = os.path.join(target_folder, self.__release_folder)
        archive_folder = os.path.join(target_folder, self.__release_folder)
        if (os.path.exists(folder)):
          print(f"Directory {folder} exists. Renaming...")
          incr = 1
          archive_folder = os.path.join(target_folder, self.__release_folder+"_" + str(incr))
          while(os.path.exists(archive_folder)):
            incr += 1
            archive_folder = os.path.join(target_folder, self.__release_folder+"_" + str(incr))
          os.rename(folder, archive_folder)

        print(f"Creating directory : {folder}")
        os.mkdir(folder)
      except Exception as e:
        error_string = "Something has gone wrong - " + str(e)
        print(error_string)
        sys.exit(1)

  @get_function_name
  def _create_nested_directories(self, base_path, *subdirs):
    current_path = pathlib.Path(base_path)
    for subdir in subdirs[0]:
      current_path = pathlib.Path(current_path) / subdir
      if not current_path.exists():
        try:
          os.mkdir(current_path)
        except Exception as e:
          print(f"Failed to create {current_path}: {e}")
          return False
    return True

  @get_function_name
  def _check_dir_exists_create(self, release_dir_file: str, manifest_path: str):
    try:
      if os.path.exists(os.path.join(self.__unisrc_nas_folder, 'unisrc', os.path.dirname(manifest_path))):
        return True
      else:
        if self._create_nested_directories(self.__unisrc_nas_folder, str('unisrc/'+str(os.path.dirname(manifest_path))).split("/")):
          return True
        else:
          return False
    except Exception as e:
      error_string = f"Something has gone wrong - {str(e)}"
      print(error_string)
      sys.exit(1)

  @get_function_name
  def _copy_source_to_unisrc(self, release_dir_file: str, manifest_path: str):
    try:
      if self._check_dir_exists_create(release_dir_file, manifest_path):
        shutil.copy(release_dir_file, os.path.join(self.__unisrc_nas_folder, 'unisrc', manifest_path))
      else:
        print(f"\033[31mError: not able to copy release file : {manifest_path} to unisrc_nas path : {self.__unisrc_nas_folder}\033[0m")
      
    except Exception as e:
      error_string = f"Something has gone wrong - {str(e)}"
      print(error_string)
      sys.exit(1)

  @get_function_name
  def _copy_to_rollback_dest(self, file_path, rollback_dest_path, dest_abs_path: str, filename: str):
    """
    Copy file_path into rollback_dest_path.
    - If rollback_dest_path does not exist: create nested directories then copy.
    - If rollback_dest_path exists and file already copied: skip (continue).
    - If rollback_dest_path exists and file not yet copied: copy.
    """
    if not rollback_dest_path.exists():
      if self._create_nested_directories(os.path.join(self.__release_rollback_dir, self.__release_folder), str(dest_abs_path).split("/")):
        shutil.copy(file_path, rollback_dest_path)
        print(f"\033[32mFile copied to {rollback_dest_path}\033[0m")
    else:
      if os.path.exists(os.path.join(rollback_dest_path, filename)):
        print("\033[33mFile already exists no need to copy again. continue...\033[0m")
      else:
        shutil.copy(file_path, rollback_dest_path)
        print(f"\033[32mFile copied to {rollback_dest_path}\033[0m")

  @get_function_name
  def _rollback_backup(self, filename: str, target_path: str, manifest_file_path: str, chk_basefile_exists: str = 'N'):
    try:
      if not os.path.exists(os.path.join(self.__release_rollback_dir, self.__release_folder)):
        self._create_dir(self.__release_rollback_dir)

      if chk_basefile_exists == 'N':
        file_path = pathlib.Path(os.path.join(target_path, manifest_file_path))
      else:
        file_path = pathlib.Path(os.path.join(target_path, filename))
      if file_path.exists():
        dest_abs_path = os.path.dirname(manifest_file_path)
        rollback_dest_path = pathlib.Path(os.path.join(self.__release_rollback_dir, self.__release_folder, dest_abs_path))

        self._copy_to_rollback_dest(file_path, rollback_dest_path, dest_abs_path, filename)
      else:
        print(f"\033[33mFile {file_path} not available for rollback backup, might be placing new file. Please verify.\033[0m")

    except Exception as e:
      error_string = f"Something has gone wrong - {str(e)}"
      print(error_string)
      sys.exit(1)

  @get_function_name
  def _untar_file(self):
    try:
      rel_folder = os.path.join(self.__release_tar_dir, self.__release_folder)

      self._create_dir(self.__release_tar_dir)

      print(f"Moving tar {self.__tar_file} to directory {rel_folder}")
      shutil.move("./"+self.__tar_file, rel_folder+"/"+self.__tar_file) 

      print(f"Extracting tar file {rel_folder}/{self.__tar_file}")
      subprocess.run(["tar", "-xvf", rel_folder+"/"+self.__tar_file], cwd=rel_folder, check=True)

    except subprocess.CalledProcessError as e:
        error_string = f"Something has gone wrong during subprocess untar - {str(e)}"
        print(error_string)
        sys.exit(1)
    except Exception as e:
      error_string = f"Something has gone wrong - {str(e)}"
      print(error_string)
      sys.exit(1)
 
  @get_function_name 
  def _download_release_tar(self):
    try:
      if not self.__release_repo:
        artifactory_repo = 'unidata-docker-local-dev' if self._get_environment() != 'PRD' else 'unidata-docker-local-release'
      else:
        artifactory_repo = 'unidata-docker-local-release'

      if not self.__release_repo:
        artifactory_folder = str(self.__branch_name).lower() if self._get_environment() != 'PRD' else str(self.__release_date).replace('release_', '')
      else:
        artifactory_folder = str(self.__release_date).replace('release_', '')

      curl_cmd = f"curl -u {os.getenv('ARTIFACTORY_CREDS_USR')}:{os.getenv('ARTIFACTORY_CREDS_PSW')} -L -o {self.__tar_file} https://artifactory.cib.echonet/artifactory/{artifactory_repo}/unisrc/releases/{artifactory_folder}/{self.__tar_file}"
      print(f"\033[37mcurl_cmd : {curl_cmd}\033[0m")

      result = subprocess.Popen([curl_cmd], stdout=subprocess.PIPE, shell=True)
      (out, err) = result.communicate()
      # Check if the command was successful
      if result.returncode != 0:
        print(f"Command : {curl_cmd} failed with return code {result.returncode}. Error: {err.decode('utf-8')}")
      else:
        print(f"File downloaded in path : {self.__release_tar_dir}/{self.__tar_file}")
    except (subprocess.CalledProcessError, ValueError, AttributeError) as err:
      error_string = f"Something has gone wrong on subprocess - {str(err)}"
      print(error_string)
      sys.exit(1)
    except Exception as e:
      error_string = f"Something has gone wrong - {str(e)}"
      print(error_string)
      sys.exit(1)

def main ():
  try:
    parser = argparse.ArgumentParser(description='Unisrc release deployment')
    parser.add_argument("-r", "--release", help="release_<release_date> to download particular tar, read manifest and create directories", type=str, required=True)
    parser.add_argument("-b", "--branch", help="branch name to download the tar from particular folder in artifactory repo", type=str, required=False)
    parser.add_argument("-R", "--release_repo", help="to identify which artifactory repository to be used to pull tar files", action='store_true')

    args = parser.parse_args()
    release_no = args.release
    if not args.release_repo:
      if not args.branch:
        print("error: branch name should be passed with -b flag. exiting.")
        sys.exit(1)
      else:
        branch_name = args.branch
    else:
      branch_name = ''

    release_repo = args.release_repo

    release_deploy = ReleaseDeployment(release_no, branch_name, release_repo)
    release_deploy._download_release_tar()
    release_deploy._untar_file()
    release_deploy._read_manifest_file()
    print("\033[32mRelease deployment execution completed successfully.\033[0m")
  except Exception as e:
    error_string = f"\033[31mSomething has gone wrong - {str(e)}.\033[0m"
    print(error_string)
    sys.exit(1)

if __name__ == "__main__":
  main()