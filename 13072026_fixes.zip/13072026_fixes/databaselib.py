import sys
import oracledb
import pandas as pd
from create_logger import get_logger
from pyconnection import get_connection
from pathlib import Path
DEBUG=False

logger = get_logger()
VALID_ARGUMENTS_MSG = "Please pass valid arguments"

def do_sql_returns_data(sql: str) -> bool:
    """
        Determine whether an SQL query returns data.

        Args:
            sql (str): The SQL query to check.

        Returns:
            bool: True if the query returns data, False otherwise.

        Notes:
            This function checks the type of SQL query to determine whether it returns data.
            It considers the following types of queries to return data:
                - SELECT statements that do not contain an INTO clause
                - EXEC statements
                - Stored procedures that start with 'SP_'
    """

    sql = sql.strip()

    if ((sql.split(' ')[0].upper() == "SELECT") and (" INTO " not in sql.upper())):
        return True
    elif sql.split(' ')[0].upper() == 'EXEC' or  sql.split(' ')[0][:3].upper() == 'SP_' :
        return True
    else:
        return False

def exec_sql(sql: str, db_name: str = 'ORACLE', get_header: bool = False, skip_db_error: bool = False, batch_size: int = 1000) -> list:
    """
        Execute an SQL query on a given database.

        Args:
            db_name (str): The name of the database.
            sql (str or list): The SQL query to execute. If a list, it is assumed to be a batch of queries.
            get_header (bool, optional): Whether to include the column headers in the result. Defaults to False.
            skip_db_error (bool, optional): Whether to skip database errors and continue executing. Defaults to False.

        Returns:
            list: The result of the SQL query execution, or an empty list if the query does not return data.

        Raises:
            sys.exit(1): If a connection to the database cannot be established or if invalid arguments are passed.

        Notes:
            This function uses the `DEBUG` variable to control whether the SQL query is printed to the console.
            The `batch_size` variable must be a positive integer if a list of queries is passed.
    """
    if DEBUG:
        print(f"{sql}")

    try:

        if isinstance(sql, list) and (not isinstance(batch_size, int) or batch_size <= 0):
            logger.error(VALID_ARGUMENTS_MSG)
            raise ValueError(VALID_ARGUMENTS_MSG)

        conn = get_connection(db_name)

        if conn:

            if str(db_name).upper() == "ORACLE":
                return exec_oracle(conn, db_name, sql, get_header, skip_db_error)

        else:
            logger.error(f"Could not connect to database {db_name}")
            raise RuntimeError(f"Error getting connection to database : {db_name}")
    except oracledb.DatabaseError as e:
        logger.error(f"Error executing sql : {e}")
        raise ValueError(f"Oracledb Database error : {e}")
    except ValueError as e:
        logger.error(f"Error getting connection : {e}")
        raise ValueError(f"Error getting connection or executing sql : {e}")
    except Exception as e:
        logger.error(f"Unexpected error occurred during get_connection : {e}")
        raise RuntimeError(f"Unexpected error occurred during get_connection : {e}")


def exec_oracle(conn: oracledb.Connection, db_name: str, sql: str, get_header: bool, skip_db_error: bool) -> list:
    """
        Execute an Oracle SQL query on a given database connection.

        Args:
            conn (oracledb.Connection): The Oracle database connection.
            db_name (str): The name of the database.
            sql (str): The SQL query to execute.
            get_header (bool, optional): Whether to include the column headers in the result. Defaults to True.
            skip_db_error (bool, optional): Whether to skip database errors and continue executing. Defaults to False.

        Returns:
            list: The result of the SQL query execution, or an empty list if the query does not return data.

        Raises:
            oracledb.DatabaseError: If a database error occurs and skip_db_error is False.
    """
    sql_output = []

    try:
        query_cur = conn.cursor()

        query_cur.execute(sql)

        if do_sql_returns_data(sql):
            query_cur_recs = query_cur.fetchall()

            if get_header == True:
                query_cur_recs.insert(0, tuple(column[0] for column in query_cur.description))

            sql_output = query_cur_recs

            return sql_output
        else:
            return sql_output

    except oracledb.DatabaseError as e:
        error = e.args[0]
        if hasattr(error, 'is_session_dead'):
            logger.error(f"Error connection lost : {error.message}")
        else:
            logger.error(str(e.args[0]))
            logger.error(f"Error executing {sql} on database {db_name}")
        if skip_db_error:
            print ("Continuing with errors")
        else:
            raise
    finally:
        if query_cur is not None:
            query_cur.close()
            del query_cur
        if conn is not None:
            conn.close()
            del conn

def execmany_sql(sql: str, params: list | str | None, db_name: str = 'ORACLE') -> None:
    if DEBUG:
        print(f"{sql}")
    try:

        conn = get_connection(db_name)

        if not conn:
            logger.error(f"Could not connect to database {db_name}")
            raise ValueError(f"Could not connect to database {db_name} during execmany_sql...")

        if isinstance(params, pd.DataFrame):
            print (VALID_ARGUMENTS_MSG)
            logger.error(VALID_ARGUMENTS_MSG)
            raise ValueError("Pass valid arguments to run execmany_sql function... ")

        query_cur = conn.cursor()

        query_cur.executemany(sql, params)

    except oracledb.DatabaseError as e:
        error = e.args[0]
        logger.error(error)
        logger.error(f"Error executing {sql} on database {db_name}")
        raise ValueError(f"Oracledb Database error : {e} and error : {error}")
    except ValueError as e:
        raise ValueError(f"Error executing sql in execmany_sql... {e}")
    except Exception as e:
        raise RuntimeError(f"Error executing sql in execmany_sql... {e}")
    finally:
        if query_cur is not None:
            query_cur.close()
            del query_cur
        if conn is not None:
            conn.close()
            del conn