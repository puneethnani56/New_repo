import os
import sys
import re
import time
import oracledb
from datetime import datetime
from glob import glob
from create_logger import get_logger
import common_sql_functions as csf
import get_business_date as bd
from databaselib import exec_sql

# LOGGING CONFIG
logger = get_logger()

def file_check(directory, file_pattern):
    # Use list() constructor instead of redundant comprehension (Sonar: line 18)
    files = list(glob(os.path.join(directory, '**', file_pattern), recursive=True))
    return files

def _check_matched_files(matched: list, directory: str, file_name: str, file_pattern: str, missing_files: list) -> None:
    """Check match results and populate missing_files list. Raises RuntimeError on duplicates."""
    if matched:
        if len(matched) == 1:
            for f in matched:
                logger.info(f"{logger_prefix} Matched file: {f}")
        elif len(matched) > 1:
            logger.error(f"{logger_prefix} Duplicate files found : {matched} in directory : {directory} for file : {file_name}")
            raise RuntimeError(f"Duplicate files found : {matched} in directory : {directory} for file : {file_name}")
    else:
        missing_files.append(f"{directory}/{file_pattern}")
        logger.warning(f"{logger_prefix} Missing file detected {directory}/{file_name}")


def process_files(app_name, extract_task_name):

    extract_task_id = csf.get_task_id(app_name, extract_task_name)
    missing_files = []
    sql = (f"SELECT file_pattern, file_path, source_path, date_format, threshold_time FROM ts_file_watcher WHERE task_id = {extract_task_id} AND status = 'A'")

    try:
        records = exec_sql(sql)
        threshold_time = None

        for file_pattern, file_path, source_path, date_format, th_time in records:
            if threshold_time is None:
                threshold_time = th_time

            directory = os.path.join(file_path, source_path)
            bus_date = csf.get_app_business_date(app_name)

            file_name = str(file_pattern).replace('{currdate}', bd.convert_to_date_format(bus_date[1], date_format)).replace('{prevdate}', bd.convert_to_date_format(bus_date[0], date_format)).replace('{nextdate}', bd.convert_to_date_format(bus_date[2], date_format)).replace('{nextcalendardate}', bd.convert_to_date_format(bus_date[1], date_format, 1))

            matched = file_check(directory, file_name)
            _check_matched_files(matched, directory, file_name, file_pattern, missing_files)

        return missing_files, threshold_time

    except RuntimeError:
        raise
    except Exception as e:
        logger.error(f"{logger_prefix} Exception occurred on process_files for app_name : {app_name} and task_name : {extract_task_name}: {e}")
        raise RuntimeError(f"Exception occurred during process_files for app_name : {app_name} and extract_task_name : {extract_task_name}")


def _resolve_threshold(threshold_time) -> object:
    """Convert threshold_time (str, datetime, or time) to a time object."""
    if isinstance(threshold_time, str):
        try:
            return datetime.strptime(threshold_time, "%H:%M:%S").time()
        except ValueError:
            return datetime.strptime(threshold_time, "%H:%M").time()
    elif isinstance(threshold_time, datetime):
        return threshold_time.time()
    return threshold_time


def _evaluate_threshold(missing_files: list, threshold_time) -> bool:
    """
    Evaluate whether threshold has been exceeded and act on missing files.
    Returns True if the while-loop should break (all present or partial success).
    Raises RuntimeError if all files missing after threshold.
    """
    threshold_obj = _resolve_threshold(threshold_time)
    now = datetime.now().time()

    if now > threshold_obj:
        if len(missing_files) < 8:
            logger.error(
                f"{logger_prefix} Threshold ({threshold_obj}) exceeded but {len(missing_files)} "
                f"expected files are missing. Missing: {missing_files}. Marking as SUCCESS."
            )
            return True
        else:
            logger.error(
                f"{logger_prefix} Threshold ({threshold_obj}) exceeded and ALL 8 expected files "
                f"are missing. Missing: {missing_files}. Failing the job."
            )
            raise RuntimeError("All expected files missing after threshold — job failed")
    return False


def main():
    app_name = os.getenv("APP_NAME")
    task_name = os.getenv("TASK_NAME")
    extract_task_name = os.getenv("EXTRACT_TASK_NAME")
    dag_ref = os.getenv("DAG_REF")
    node_name = os.getenv("NODE_NAME")
    run_mode = str(dag_ref).split('__')[0].split('-')[1]
    retry_interval = 900

    try:
        if not task_name or not app_name:
            raise KeyError("task_name or app_name. Environment variables for these variables are not set.")

        business_date = csf.get_app_business_date(app_name)
        csf.update_ts_task_status(app_name, task_name, business_date[1], dag_ref, run_mode, 'processing', 'processing file watcher')
        ts_instance = csf.get_task_instance(app_name, task_name, dag_ref)

        global logger_prefix
        logger_prefix = f"[{ts_instance}] [{node_name}]"

        while True:
            missing_files, threshold_time = process_files(app_name, extract_task_name)

            if not missing_files:
                logger.info(f"{logger_prefix} All files are present")
                break

            if _evaluate_threshold(missing_files, threshold_time):
                break

            time.sleep(retry_interval)

        csf.update_ts_task_status(app_name, task_name, business_date[1], dag_ref, run_mode, 'completed', 'file watcher completed')
        logger.info(f"{logger_prefix} File watcher task : {task_name} completed for business date : {business_date[1]} and dag_ref : {dag_ref}")
        sys.exit(0)

    except Exception as e:
        logger.error(f"Exception caught : {e}")
        csf.update_ts_task_status(app_name, task_name, business_date[1], dag_ref, run_mode, 'error', 'error processing file watcher')
        sys.exit(1)

if __name__ == "__main__":
    main()