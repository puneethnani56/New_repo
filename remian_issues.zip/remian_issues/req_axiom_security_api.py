import os
import sys
import datetime
import io
import json
import requests
import shutil
import time
import uuid
import jwt
import gzip
import csv
import argparse
import pandas as pd
from pathlib import Path
from typing import Optional, Any, List, Tuple, Dict, Set, Union, Literal
from datetime import datetime, timedelta, timezone

from oauthlib.oauth2 import BackendApplicationClient
from requests_oauthlib import OAuth2Session
from requests.exceptions import HTTPError
from urllib.parse import urljoin
from urllib3.util.retry import Retry

## user package
import read_json as rj
import json_writer as jw
from create_logger import get_logger
from databaselib import exec_sql, execmany_sql
import common_sql_functions as dbm
from createPayloadJson import trigger_payload
import copy_output_file as cp
import get_business_date as bd

## Initialize logger to log on file
logger = get_logger()

####################################################
##      get expiration for the certificate        ##
####################################################
def check_credential_expiration(expiry_date: int, valid_check_days: int) -> bool:
    """
    Check the expiration status of credentials based on the provided expiry date.

    Args:
        expiry_date (int): The expiration date of the credentials in milliseconds since the epoch.
        valid_check_days (int): Number of days to throw the credential expiry alert.

    return boolean:

    Logs:
        - Error: If the credentials have expired.
        - Warning: If the credentials are expiring within 30 days.
        - Info: If the credentials are valid and not expiring within 30 days.
    """
    EXPIRES_IN = datetime.fromtimestamp(expiry_date / 1000, TIMEZONE) - datetime.now(TIMEZONE)
    if EXPIRES_IN.days < 0:
        logger.error(f"{logger_prefix} Credentials expired {EXPIRES_IN.days} days ago")
        return False
    elif EXPIRES_IN < timedelta(days=valid_check_days):
        logger.warning(f"{logger_prefix} Credentials expiring in {EXPIRES_IN}")
    else:
        logger.info(f"{logger_prefix} Credentials expiring in {EXPIRES_IN}")
    return True

def add_busdate_column(output_csv_file: str, record_delimiter: str) -> None:
    logger.info(f"{logger_prefix} Adding business date column for file : {output_csv_file}")

    try:
        if not os.path.exists(output_csv_file):
            logger.error(f"{logger_prefix} File {output_csv_file} does not exist...")
            raise FileNotFoundError(f"File {output_csv_file} does not exist...")

        # Read the CSV file
        df = pd.read_csv(output_csv_file, sep=record_delimiter)

        # Add a new column
        df.insert(0, 'BUSINESS_DATE', str(business_date[1]))

        df.to_csv(output_csv_file, sep=record_delimiter, index=False)
    except FileNotFoundError as e:
        logger.error(f"{logger_prefix} File not found : {e}")
        raise Exception(f"File not found : {e} during add_busdate_column.")
    except Exception as e:
        logger.error(f"{logger_prefix} An unexpected error occurred while adding business date column : {e}")
        raise Exception(f"An unexpected error occurred while adding business date column : {e}")

def _build_output_filenames(security_category: str) -> tuple:
    """Build (output_file_name, output_json_file_name, output_csv_file_name) from global params."""
    output_file_name = (
        str(output_param_filename)
        .replace('{securityCategory}', security_category)
        .replace('{currdate}', bd.convert_to_date_format(business_date[1], output_param_datefmt))
        .replace('{prevdate}', bd.convert_to_date_format(business_date[0], output_param_datefmt))
        .replace('{nextdate}', bd.convert_to_date_format(business_date[2], output_param_datefmt))
        if output_param_filename and output_param_datefmt else None
    )
    if not output_file_name:
        return None, None, None
    json_ext = f"{str(output_file_name).split('.')[0]}.json"
    output_json_file_name = os.path.join(download_path, json_ext)
    output_csv_file_name = os.path.join(download_path, output_file_name)
    return output_file_name, output_json_file_name, output_csv_file_name


def _resolve_security_master_json(file_dict: dict, output_json_file_name: str, retried_securities: list) -> str:
    """Return the resolved output_json_file_name for securityMaster category."""
    if len(file_dict) == 2:
        if set(file_dict.values()) == {'N', 'Y'}:
            n_file = next(k for k, v in file_dict.items() if v == 'N')
            y_file = next(k for k, v in file_dict.items() if v == 'Y')
            n_file_json = rj.read_json_file(n_file)
            y_file_json = rj.read_json_file(y_file)
            merged = [obj for obj in n_file_json if obj['IDENTIFIER'] not in retried_securities]
            merged.extend(y_file_json)
            with open(output_json_file_name, "w") as fout:
                fout.write(json.dumps(merged, indent=4))
    elif len(file_dict) == 1:
        output_json_file_name = list(file_dict.keys())[0]
    else:
        logger.error(f"{logger_prefix} Expected 1 or 2 entries in bbg_api_response_details for securityMaster.")
        raise RuntimeError("Expected 1 or 2 entries in bbg_api_response_details for securityMaster.")
    return output_json_file_name


def _convert_and_update_output(output_json_file_name: str, output_csv_file_name: str,
                                bus_date: str, task_inst: int, run_mode: str, security_category: str) -> None:
    """Convert JSON to CSV, add business date column, and update DB record."""
    if os.path.exists(output_json_file_name):
        logger.info(f"{logger_prefix} Converting JSON : {output_json_file_name} to CSV : {output_csv_file_name}")
        jw.json_to_csv(output_json_file_name, output_csv_file_name, output_param_delimiter)
        logger.info(f"{logger_prefix} Converted JSON to CSV : {output_csv_file_name}")

    add_busdate_column(output_csv_file_name, output_param_delimiter)
    logger.info(f"{logger_prefix} Added business date column on : {output_csv_file_name}")

    update_sql = (
        f"UPDATE bbg_api_response_details SET output_shared_file = '{output_csv_file_name}' "
        f"WHERE business_date = TO_DATE('{bus_date}', 'YYYYMMDD') AND task_instance = {task_inst} "
        f"AND run_mode = '{run_mode}' AND security_category = '{security_category}' AND output_status = 'completed'"
    )
    logger.info(f"{logger_prefix} Executing sql : {update_sql}")
    exec_sql(update_sql)


def produce_output_file(bus_date: str, task_inst: int, run_mode: str, security_category: str, retried_securities: list) -> None:
    logger.info(f"{logger_prefix} Producing output file for category : {security_category}, task_instance : {task_inst}, business_date : {bus_date}")

    try:
        retrieve_file_sql = (
            f"select output_file_path, is_retry FROM BBG_API_RESPONSE_DETAILS "
            f"WHERE task_instance = {task_inst} AND business_date = TO_DATE('{bus_date}', 'YYYYMMDD') "
            f"AND run_mode = '{run_mode}' AND security_category = '{security_category}' AND output_shared_file is null"
        )
        logger.info(f"{logger_prefix} Executing sql : {retrieve_file_sql}")
        output_file_data = exec_sql(retrieve_file_sql)

        if not output_file_data:
            logger.warning(f"{logger_prefix} File already produced or no record found for category : {security_category}, task_instance : {task_inst}, business_date : {bus_date}.")
            return

        file_dict = dict(output_file_data)
        _, output_json_file_name, output_csv_file_name = _build_output_filenames(security_category)

        if output_csv_file_name is None:
            logger.error(f"{logger_prefix} Output file name not exists on ts_task_output_params for task : {task_name}.")
            raise RuntimeError(f"Output file name not exists on ts_task_output_params for task : {task_name} during produce_output_file.")

        logger.info(f"{logger_prefix} Creating final json for category : {security_category}.")
        if security_category == 'securityMaster':
            output_json_file_name = _resolve_security_master_json(file_dict, output_json_file_name, retried_securities)
        elif security_category == 'pricingData':
            output_json_file_name = list(file_dict.keys())[0]

        logger.info(f"{logger_prefix} output_json_file_name : {output_json_file_name}")
        logger.info(f"{logger_prefix} output_csv_file_name : {output_csv_file_name}")

        _convert_and_update_output(output_json_file_name, output_csv_file_name, bus_date, task_inst, run_mode, security_category)

    except RuntimeError:
        raise
    except Exception as e:
        raise RuntimeError(f"Unexpected exception in produce_output_file for category : {security_category}, task_instance : {task_inst}, business_date : {bus_date} as {e}")


class DLRestApiSession(OAuth2Session):
    """Custom session class for making requests to a DL REST API using OAuth2 authentication."""

    oauth2_endpoint = "https://bsso.blpprofessional.com/ext/api/as/token.oauth2"
    instances = dict()

    def __new__(cls, client_id: str, client_secret: str, *args, **kwargs):
        """
        Provide a global point of access to the instance of this class.
        Ensure only one instance per client_id is created.
        """

        if not cls.instances.get(client_id):
            cls.instances[client_id] = super().__new__(cls)

        return cls.instances[client_id]

    def __init__(self, client_id: str, client_secret: str, *args, **kwargs):
        """
        Initialize a DLRestApiSession instance.
        """
        '''Creates an instance of BackendApplicationClient using the client_id'''
        self.client = BackendApplicationClient(client_id=client_id)

        """
        Initialize the parent class (OAuth2Session) with the client object.
        The parent class does not need the client_secret at this point because the client_secret is used when fetching the token, 
        not during the initialization of the session
        """
        super().__init__(client=self.client, *args, **kwargs)

        self.client_id = client_id
        self.client_secret = client_secret

        '''Initialize the variable to store the token expiration time'''
        self._token_expires_at = 0

        '''Method fetches the OAuth2 token using the client_secret'''
        self._request_token()

    def _request_token(self):
        """
        Fetch an OAuth2 access token by making a request to the token endpoint.
        """
        self.access_token = self.fetch_token(
            token_url=self.oauth2_endpoint,
            client_secret=self.client_secret
        ).get("access_token")

        decoded_data = jwt.decode(
            jwt=self.access_token, options={"verify_signature": False}
        )
        self._token_expires_at = decoded_data["exp"]

    def _ensure_valid_token(self):
        """
        Ensure that OAuth2 access token is valid. Fetch a new token if the token is expired.
        """
        if not self.access_token:
            raise RuntimeError("\n\tAccess token error")

        valid_min_duration_threshold = 5
        seconds_until_expiration = self._token_expires_at - time.time()

        if valid_min_duration_threshold >= seconds_until_expiration:
            self._request_token()

        return

    def request(self, *args, **kwargs):
        """
        Override the parent class method to request OAuth2 token.
        :return: response object from the API request
        """
        if kwargs.get("url") != self.oauth2_endpoint:
            self._ensure_valid_token()

        return super().request(*args, **kwargs)

    def send(self, request, **kwargs):
        """
        Override the parent class method to log request and response information.
        :param request: prepared request object
        :return: response object from the API request
        """
        logger.info(
            f"{logger_prefix} Request being sent to HTTP server: %s, %s, %s",
            request.method,
            request.url,
            request.headers,
        )

        response = super().send(request, **kwargs)

        logger.info(f"{logger_prefix} Response status: {response.status_code}")
        logger.info(f"{logger_prefix} Response x-request-id: {response.headers.get('x-request-id')}")

        try:
            response.raise_for_status()
        except HTTPError as exc:
            logger.error(f"{logger_prefix} \tUnexpected response status code: {str(response.status_code)}\nDetails: {response.json()}")
            raise exc
        else:
            # Filter out SSE and file download responses.
            if response.headers.get(
                    "Content-Type"
            ) != "text/event-stream" and not response.headers.get(
                "Content-Disposition"
            ) and response.content:
                logger.info(f"{logger_prefix} Response content received... for x-request-id : {response.headers.get('x-request-id')}")
            else:
                logger.info(f"{logger_prefix} Response content either not received or not displayed inline or it is not an Server Send Event (SSE).")

        return response

# main #
app_name = os.getenv('APP_NAME')
task_name = os.getenv('AXIOM_SEC_TASK_NAME')
extract_taskname = os.getenv('EXTRACT_TASK_NAME')
dag_ref = os.getenv('DAG_REF')
node_name = os.getenv('NODE_NAME')

## read/define credentials
client_id = os.getenv("BBG_CLIENT_ID")
client_secret = os.getenv("BBG_CLIENT_SECRET")
cred_expiry_date = os.getenv("BBG_EXPIRATION_DATE")
TIMEZONE = timezone.utc


def _get_catalog_id(session: 'DLRestApiSession') -> str:
    """Fetch the scheduled catalog identifier from the BBG API."""
    catalogs_url = urljoin(HOST, '/eap/catalogs/')
    response = session.get(catalogs_url)
    logger.info(f"{logger_prefix} catalogs response: {response}")
    for catalog in response.json()['contains']:
        if catalog['subscriptionType'] == 'scheduled':
            catalog_id = catalog['identifier']
            logger.info(f"{logger_prefix} catalog_id : {catalog_id}")
            return catalog_id
    logger.error(f"{logger_prefix} Scheduled catalog not in %r", response.json()['contains'])
    raise RuntimeError('Scheduled catalog not found')


def _create_bbg_request(session: 'DLRestApiSession', catalog_id: str, payload_json: dict) -> tuple:
    """POST the request payload and return (request_url, request_id, request_name)."""
    catalog_url = urljoin(HOST, '/eap/catalogs/{c}/'.format(c=catalog_id))
    requests_url = urljoin(catalog_url, 'requests/')
    logger.info(f"{logger_prefix} requests_url : {requests_url}")
    response = session.post(requests_url, json=payload_json)
    logger.info(f"{logger_prefix} response status_code : {response.status_code}")
    request_location = response.headers['Location']
    request_url = urljoin(HOST, request_location)
    request_id = json.loads(response.text)['request']['identifier']
    logger.info(f"{logger_prefix} request_url : {request_url}, request_id : {request_id}")
    session.get(request_url)  # inspect newly-created request
    return request_url, request_id, payload_json['name']


def _poll_for_output(session: 'DLRestApiSession', catalog_id: str, request_name: str, request_id: str) -> tuple:
    """Poll until output is available or timeout. Returns (output_url, output_key, output_file_path)."""
    responses_url = urljoin(HOST, '/eap/catalogs/{c}/content/responses/'.format(c=catalog_id))
    params = {'prefix': request_name, 'requestIdentifier': request_id}
    reply_timeout_minutes = 45
    expiration_timestamp = datetime.now(TIMEZONE) + timedelta(minutes=reply_timeout_minutes)
    logger.info(f"{logger_prefix} Polling until {expiration_timestamp} (timeout={reply_timeout_minutes}min)")

    while datetime.now(TIMEZONE) < expiration_timestamp:
        try:
            content_responses = session.get(responses_url, params=params)
            response_contains = json.loads(content_responses.text)['contains']
            if len(response_contains) > 0:
                output = response_contains[0]
                output_key = output['key']
                output_url = urljoin(HOST, '/eap/catalogs/{c}/content/responses/{key}'.format(c=catalog_id, key=output_key))
                output_file_path = os.path.join(download_path, output_key)
                return output_url, output_key, output_file_path
            logger.info(f"{logger_prefix} Content not ready yet. Waiting {poll_timer_seconds}s...")
            time.sleep(poll_timer_seconds)
        except Exception as e:
            logger.warning(f"{logger_prefix} Network delay during polling: {e}. Retrying...")
            time.sleep(poll_timer_seconds)

    logger.error(f"{logger_prefix} Response not received within {reply_timeout_minutes} minutes.")
    raise RuntimeError(f"BBG API response timeout after {reply_timeout_minutes} minutes.")


def _download_output_file(session: 'DLRestApiSession', output_url: str, output_file_path: str) -> dict:
    """Download the output file and return its parsed JSON content."""
    output_json = {}
    with session.get(output_url, stream=True) as response:
        response.raise_for_status()
        logger.info(f"{logger_prefix} output_file_path : {output_file_path}")
        if response.headers.get('content-encoding') == 'gzip':
            response.raw.decode_content = True
        raw_buffer = io.BytesIO()
        shutil.copyfileobj(response.raw, raw_buffer)
        raw_buffer.seek(0)
        with open(output_file_path, 'wb') as out_file:
            shutil.copyfileobj(raw_buffer, out_file)
        raw_buffer.seek(0)
        raw_bytes = raw_buffer.read()
        try:
            output_json = json.loads(raw_bytes.decode("utf-8"))
            logger.info(f"{logger_prefix} JSON payload received at : {output_file_path}")
        except json.JSONDecodeError as e:
            logger.error(f"{logger_prefix} Payload is not valid JSON : {e}")
    logger.info(f"{logger_prefix} File downloaded: {output_file_path}")
    return output_json


def _handle_retry_logic(output_json: list, security_category: str, is_retry: str) -> None:
    """Update securities table and trigger retry for CUSIP→ISIN if needed."""
    update_sql = (
        f"UPDATE bbg_extract_securities SET dl_request_id = :1, dl_request_name = :2, rc_code = :3, "
        f"dl_snapshot_start_time = TO_TIMESTAMP(:4, 'YYYY-MM-DD\"T\"HH24:MI:SS'), is_retry = '{is_retry}' "
        f"WHERE task_instance = {extract_task_instance} AND business_date = TO_DATE('{business_date[1]}', 'YYYYMMDD') "
        f"AND security_category = '{security_category}' AND security = :5"
    )
    params = [(r['DL_REQUEST_ID'], r['DL_REQUEST_NAME'], r['RC'], r['DL_SNAPSHOT_START_TIME'], r['IDENTIFIER']) for r in output_json]
    execmany_sql(update_sql, params)

    if security_category != 'securityMaster':
        return

    logger.info(f"{logger_prefix} Checking RC=10 records for retry...")
    sql = (
        f"SELECT security, identifier_type FROM bbg_extract_securities "
        f"WHERE task_instance = {extract_task_instance} AND business_date = TO_DATE('{business_date[1]}', 'YYYYMMDD') "
        f"AND security_category = '{security_category}' AND rc_code = 10 AND IDENTIFIER_TYPE = 'CUSIP' AND is_retry = 'N'"
    )
    records = exec_sql(sql)
    logger.info(f"{logger_prefix} RC=10 CUSIP records : {len(records)}")
    if not records:
        return

    sec_data = [('SECURITY', 'IDENTIFIER_TYPE')]
    for item in records:
        sec_data.append((item[0], 'ISIN'))
        retried_securities.append(item[0])

    if len(sec_data) > 1:
        retry_sec_str = "'" + "','".join(str(s).strip() for s in retried_securities) + "'"
        update_retry_sql = (
            f"UPDATE bbg_extract_securities SET is_retry = 'Y' "
            f"WHERE task_instance = {extract_task_instance} AND business_date = TO_DATE('{business_date[1]}', 'YYYYMMDD') "
            f"AND security_category = '{security_category}' AND security in ({retry_sec_str}) AND identifier_type = 'CUSIP'"
        )
        exec_sql(update_retry_sql)
        logger.info(f"{logger_prefix} is_retry set to Y for {len(retried_securities)} securities.")
        request_bbg_api(security_category, sec_data, 'Y')


def _handle_retry_update(output_json: list, security_category: str) -> None:
    """Update securities table for a retry call (CUSIP→ISIN)."""
    update_sql = (
        f"UPDATE bbg_extract_securities SET dl_request_id = :1, dl_request_name = :2, rc_code = :3, "
        f"dl_snapshot_start_time = TO_TIMESTAMP(:4, 'YYYY-MM-DD\"T\"HH24:MI:SS'), identifier_type = 'ISIN' "
        f"WHERE task_instance = {extract_task_instance} AND business_date = TO_DATE('{business_date[1]}', 'YYYYMMDD') "
        f"AND security_category = '{security_category}' AND security = :6 AND rc_code = 10 AND identifier_type = 'CUSIP'"
    )
    params = [(r['DL_REQUEST_ID'], r['DL_REQUEST_NAME'], r['RC'], r['DL_SNAPSHOT_START_TIME'], r['IDENTIFIER']) for r in output_json]
    execmany_sql(update_sql, params)


def request_bbg_api(security_category: str, security_data = None, is_retry: str = 'N') -> None:
    try:
        logger.info(f"{logger_prefix} Started for security category : {security_category}, retry : {is_retry}")

        dbm.update_bbg_api_details(ts_instance, run_mode, business_date[1], security_category, is_retry)
        logger.info(f"{logger_prefix} Inserted into bbg_api_response_details for category : {security_category}")

        request_short_names = {'securityMaster': 'SM', 'pricingData': 'PL'}
        process_date = datetime.now().strftime('%Y%m%d%H%M%S')

        SESSION = DLRestApiSession(client_id=client_id, client_secret=client_secret)
        SESSION.headers['api-version'] = '2'

        payload_string = trigger_payload(security_category, dag_ref, business_date[1], run_mode, security_data)
        if not payload_string:
            raise RuntimeError(f"Payload string not received for category : {security_category}, dag_ref : {dag_ref}.")

        payload_json = rj.str_to_json(payload_string)
        if not payload_json:
            raise RuntimeError(f"Cannot convert payload to JSON for category : {security_category}, dag_ref : {dag_ref}.")

        payload_json['name'] = f"unisrc{security_category}{process_date}"
        payload_json['identifier'] = f"unisrc{request_short_names.get(security_category)}{str(uuid.uuid1())[:6]}"

        catalog_id = _get_catalog_id(SESSION)
        request_url, request_id, request_name = _create_bbg_request(SESSION, catalog_id, payload_json)
        logger.info(f"{logger_prefix} Request created at {request_url}")

        output_url, output_key, output_file_path = _poll_for_output(SESSION, catalog_id, request_name, request_id)

        output_json = _download_output_file(SESSION, output_url, output_file_path)
        logger.info(f"{logger_prefix} File downloaded: {output_key}")

        total_records = len(output_json)
        valid_records = len([r for r in output_json if r['RC'] == 0])
        dl_request_id = output_json[0]['DL_REQUEST_ID']
        dl_request_name = output_json[0]['DL_REQUEST_NAME']

        dbm.update_bbg_api_details(ts_instance, run_mode, business_date[1], security_category, is_retry,
                                   'completed', dl_request_id, dl_request_name, total_records, valid_records, output_file_path)

        if is_retry == 'N':
            _handle_retry_logic(output_json, security_category, is_retry)
        else:
            _handle_retry_update(output_json, security_category)

        produce_output_file(business_date[1], ts_instance, run_mode, security_category, retried_securities)
        logger.info(f"{logger_prefix} Output file produced and shared to NAS Path")

    except Exception as e:
        logger.error(f"{logger_prefix} An exception occurred : {e}")
        dbm.update_ts_task_status(app_name, task_name, business_date[1], dag_ref, run_mode, 'error', 'error')
        dbm.update_bbg_api_details(ts_instance, run_mode, business_date[1], security_category, is_retry, 'error')
        dbm.update_ts_task_status(app_name, extract_taskname, business_date[1], dag_ref, run_mode, 'error', 'security and pricing extract completed')
        sys.exit(1)


if __name__ == "__main__":
    business_date = dbm.get_app_business_date(app_name)

    run_mode = str(dag_ref).split('__')[0].split('-')[1]
    try:
        dbm.update_ts_task_status(app_name, task_name, business_date[1], dag_ref, run_mode, 'processing', 'processing bbg api')
        ts_instance = dbm.get_task_instance(app_name, task_name, dag_ref)

        extract_task_instance = dbm.get_task_instance(app_name, extract_taskname, dag_ref)

        global logger_prefix
        logger_prefix = f"[{ts_instance}] [{node_name}]"

        cred_expiry_valid_day = dbm.get_app_config_param(app_name, task_name, 'Bloomberg_credential_expiry_days')
        if not cred_expiry_valid_day:
            logger.error(f"{logger_prefix} Not able to find days to check the Bloomberg credential expiry validation.")
            raise Exception(f"{logger_prefix} Not able to find days to check the Bloomberg credential expiry validation.")

        cred_expiry = check_credential_expiration(int(cred_expiry_date), int(cred_expiry_valid_day['credExpiryDays']))
        if not cred_expiry:
            logger.error(f"{logger_prefix} Credentials expired...exiting. Expiry date : {cred_expiry_date}")
            raise Exception(f"Credentials expired...exiting. Expiry date : {cred_expiry_date}")
        else:
            logger.info(f"{logger_prefix} Credential expiry valid...proceeding.")

        payloads = dbm.get_app_config_param(app_name, task_name, 'Bloomberg_payload_names')
        if not payloads:
            logger.error(f"{logger_prefix} Payload names or security category data not exists in config for : Bloomberg_payload_names")
            raise Exception("Payload names or security category data not exists in config for : Bloomberg_payload_names")
        else:
            logger.info(f"{logger_prefix} payloads for task_name : {task_name} , {payloads}")

        logger.info(f"{logger_prefix} payloads : {payloads}")
        payload_request_names=[item['name'] for item in payloads['payloads']]

        output_params = dbm.get_output_params(app_name, task_name, 'Bloomberg_api_output_filepath')
        logger.info(f"{logger_prefix} output_params : {output_params}")

        output_mode = output_params[0][0] if output_params[0][0] else None
        download_path = output_params[0][1] if output_params[0][1] else None
        output_param_filename = output_params[0][2] if output_params[0][2] else None
        output_param_datefmt = output_params[0][3] if output_params[0][3] else None
        output_param_delimiter = output_params[0][4] if output_params[0][4] else ','

        if not download_path:
            logger.error(f"{logger_prefix} Output path not exists for config : Bloomberg_api_output_filepath on ts_task_output_params table. exiting..")
            raise Exception("Output path not exists for config : Bloomberg_api_output_filepath on t_task_output_params table. exiting.")
        else:
            logger.info(f"{logger_prefix} Bloomberg API download path : {download_path}")

        if not output_param_filename or not output_param_datefmt:
            logger.error(f"{logger_prefix} Output filename or date format not exists on config : Bloomberg_api_output_filepath on ts_task_output_params table. exiting..")
            raise Exception("Output filename or date format not exists on config : Bloomberg_api_output_filepath on ts_task_output_params table. exiting..")
        else:
            logger.info(f"{logger_prefix} Bloomberg output file name and date format exists.. {output_param_filename} and {output_param_datefmt}")

        ## API end points
        bbg_api_hosts = dbm.get_app_config_param(app_name, task_name, 'Bloomberg_api_host')
        if not bbg_api_hosts:
            logger.error(f"{logger_prefix} Api Host and authentication end point URL not exists on config : Bloomberg_api_host. exiting.")
            raise Exception("Api Host and authentication end point URL not exists on config : Bloomberg_api_host. exiting.")
        else:
            logger.info(f"{logger_prefix} bbg_api_hosts : {bbg_api_hosts}")

        logger.info(f"{logger_prefix} Setting Host and OAuth2_endpoint for API call...")
        # API end points
        HOST = bbg_api_hosts['apiHost']
        oauth2_endpoint_url = bbg_api_hosts['oauth2_endpoint']

        api_polltimer=dbm.get_app_config_param(app_name, task_name, 'Bloomberg_api_poll_timer')
        poll_timer_seconds=int(api_polltimer.get('apiPollTimer', 30))
        logger.info(f"{logger_prefix} Api polling time : {poll_timer_seconds} seconds.")

        # setting empty list for retried securities and this will happen only once for security Master category
        retried_securities = []

        for req in payload_request_names:
            logger.info(f"{logger_prefix} Requesting for payload : {req}")
            request_bbg_api(req)

        dbm.update_ts_task_status(app_name, task_name, business_date[1], dag_ref, run_mode, 'completed', 'bbg api completed')
        dbm.update_ts_task_status(app_name, extract_taskname, business_date[1], dag_ref, run_mode, 'completed', 'security and pricing extract completed')

        logger.info(f"{logger_prefix} Task {task_name} status updated to completed successfully.")

    except Exception as e:
        logger.error(f"{logger_prefix} An exception occurred : {e}")
        dbm.update_ts_task_status(app_name, task_name, business_date[1], dag_ref, run_mode, 'error', 'error')
        dbm.update_ts_task_status(app_name, extract_taskname, business_date[1], dag_ref, run_mode, 'error', 'security and pricing extract completed')
        sys.exit(1)