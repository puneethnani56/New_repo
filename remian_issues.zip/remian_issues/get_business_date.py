import os
import sys
from databaselib import exec_sql
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta


def get_current_year_month(date_val: str) -> tuple:
    """
    Returns the current year and month from the given date string.

    Args:
        date_val (str): The date string in the format '%d/%b/%Y'.

    Returns:
        tuple: A tuple containing the current year and month.
    """
    date_val = datetime.strptime(date_val, '%d/%b/%Y').date()
    curr_year = date_val.year
    curr_month = date_val.month

    return curr_year, curr_month

def get_previous_year_month(date_val: str) -> tuple:
    """
    Returns the previous year and month from the given date string.

    Args:
        date_val (str): The date string in the format '%d/%b/%Y'.

    Returns:
        tuple: A tuple containing the previous year and month.
    """
    date_val = datetime.strptime(date_val, '%d/%b/%Y').date()
    prev_date = (date_val - relativedelta(months=1))
    prev_year = prev_date.year
    prev_month = prev_date.month

    return prev_year, prev_month


def is_weekend_day(date_val: datetime.date) -> bool:
    """
    Checks if the given date is a weekend day.

    Args:
        date_val (datetime.date): The date to check.

    Example:
        0 = Monday and 6 = Sunday

    Returns:
        bool: True if the date is a weekend day, False otherwise.
    """
    return date_val.weekday() >= 5

def is_non_working_day(date_val: datetime.date, holiday_list: list) -> bool:
    """
    Checks if the given date is a non-working day.

    Args:
        date_val (datetime.date): The date to check.
        holiday_list (list): A list of holiday dates.

    Returns:
        bool: True if the date is a non-working day, False otherwise.
    """
    return date_val in holiday_list

def _advance_to_business_day(start_date, direction: int, holiday_date_list: list) -> str:
    """Walk start_date by direction (+1/-1) until a working day is found. Returns YYYYMMDD string."""
    current = start_date
    while is_weekend_day(current) or is_non_working_day(current, holiday_date_list):
        current += timedelta(days=direction)
    if hasattr(current, 'date'):
        return current.date().strftime('%Y%m%d')
    return current.strftime('%Y%m%d')


def _roll_dates_not_exists(date_param: str, holiday_date_list: list) -> tuple:
    """Compute (prev, curr, next) business dates when the date does NOT yet exist in DB."""
    current_candidate = datetime.strptime(date_param, '%d/%b/%Y') - timedelta(days=1)
    current_str = _advance_to_business_day(current_candidate, -1, holiday_date_list)

    prev_candidate = datetime.strptime(current_str, '%Y%m%d').date() - timedelta(days=1)
    previous_str = _advance_to_business_day(prev_candidate, -1, holiday_date_list)

    next_candidate = datetime.strptime(current_str, '%Y%m%d').date() + timedelta(days=1)
    next_str = _advance_to_business_day(next_candidate, +1, holiday_date_list)

    return previous_str, current_str, next_str


def _roll_dates_exists(date_param: str, holiday_date_list: list) -> str:
    """Compute next business date when the date already exists in DB."""
    current_str = datetime.strptime(date_param, '%d/%b/%Y').strftime('%Y%m%d')
    next_candidate = datetime.strptime(current_str, '%Y%m%d').date() + timedelta(days=1)
    return _advance_to_business_day(next_candidate, +1, holiday_date_list)


def roll_srcsys_business_date(date_param: str, src_sys: str, date_exists: str) -> str | tuple:
    """
    Returns the previous working day from the given date string.

    Args:
        date_param (str): The date string in the format '%d/%b/%Y'.
        src_sys (str): Application name as src_sys from app_config table.
        date_exists (str): 'Y' if current date already set, 'N' to compute from scratch.

    Returns:
        str or tuple: Next business date (str) if date_exists=='Y',
                      or (prev, curr, next) tuple if date_exists=='N'.
    """
    current_year, current_month = get_current_year_month(date_param)
    _, previous_month = get_previous_year_month(date_param)

    holiday_dates = exec_sql(f"SELECT holiday_dt FROM app_calendar WHERE app_name = (select app_name from app_config where app_description = '{src_sys}') AND year = {current_year} AND month IN ({current_month}, {previous_month}) OR ( {current_month} = 1 AND (year = {current_year} AND month = 1 OR year = {current_year} - 1 AND month = 12))")

    date_list = [rec[0].strftime('%Y-%m-%d') for rec in holiday_dates]
    holiday_date_list = [datetime.strptime(date, '%Y-%m-%d').date() for date in date_list]

    if date_exists == 'N':
        return _roll_dates_not_exists(date_param, holiday_date_list)
    elif date_exists == 'Y':
        return _roll_dates_exists(date_param, holiday_date_list)

def roll_unisrc_business_date(date_param: str) -> tuple:
    """
    Returns the previous, current, and next business dates from the given date string.

    Args:
        date_val (str): The date string in the format '%d/%b/%Y'.

    Returns:
        tuple: A tuple containing the previous, current, and next business dates in the format 'YYYYMMDD'.
    """
    date_val_dt = datetime.strptime(date_param, '%d/%b/%Y').date()

    # Subtract 1 day to get current business_date
    current_business_date = date_val_dt - timedelta(days=1)

    # If the current business_date is a weekend, subtract 1 day, until we get the Friday date as current business_date
    while current_business_date.weekday() >= 5:
        current_business_date -= timedelta(days=1)

    current_business_date = current_business_date.strftime('%Y%m%d')

    # Get the previous business date
    previous_business_date_dt = datetime.strptime(current_business_date, '%Y%m%d').date() - timedelta(days=1)

    # If the previous business day is a weekend, subtract 1 day, until we get the Friday date as previous business_date
    while previous_business_date_dt.weekday() >= 5:
        previous_business_date_dt -= timedelta(days=1)

    previous_business_date = previous_business_date_dt.strftime('%Y%m%d')

    # Get the next business date
    next_business_date_dt = datetime.strptime(current_business_date, '%Y%m%d').date() + timedelta(days=1)

    # If the next business day is a weekend, add 1 day, until we get the Monday date as next business_date
    while next_business_date_dt.weekday() >= 5:
        next_business_date_dt += timedelta(days=1)

    next_business_date = next_business_date_dt.strftime('%Y%m%d')

    return previous_business_date, current_business_date, next_business_date

def convert_date_ddmmyyyy(date_str: str) -> str:
    date_obj = datetime.strptime(date_str, '%Y%m%d')
    date_string = date_obj.strftime('%d%m%Y')

    return date_string

def adjust_date_format(date_str: str, source_fmt: str, dest_fmt: str) -> tuple[str, str]:
    try:
        if len(dest_fmt) > 6:
            date_str = date_str + datetime.now().strftime('%H%M%S')
            source_fmt = source_fmt+'%H%M%S'

        return date_str, source_fmt

    except ValueError as e:
        raise Exception(f"Exception occurred on adjust_date_format from get_business_date : {e}")

def convert_to_date_format(date_str: str, dest_date_format: str, add_days: int = 0) -> str:
    try:
        adjusted_date_str, src_date_format = adjust_date_format(date_str, '%Y%m%d', dest_date_format)

        date_object =  datetime.strptime(adjusted_date_str, src_date_format)

        if add_days > 0:
            date_object += timedelta(days=int(add_days))

        date_string = date_object.strftime(dest_date_format)

        return date_string
    except ValueError as e:
        raise Exception(f"Exception occurred on convert_to_date_format from get_business_date : {e}")
