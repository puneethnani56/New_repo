import os
import json
import logging
import sys
import time
import fnmatch
from datetime import datetime
from typing import List, Dict, Tuple, Optional, Union
from pathlib import Path, PureWindowsPath

# Kafka packages
from kafka import KafkaProducer, KafkaAdminClient
from kafka.admin import NewTopic
from kafka.errors import TopicAlreadyExistsError

# User-defined packages
from create_logger import get_logger
import common_sql_functions as dbm
from databaselib import exec_sql

logger = get_logger()

# ------------------------------------------------------------------
#  Kafka Environment Variables
# ------------------------------------------------------------------
KAFKA_SASL_USERNAME = os.getenv("KAFKA_SASL_USERNAME")
KAFKA_SASL_PASSWORD = os.getenv("KAFKA_SASL_PASSWORD")
SSL_CA_FILE = os.getenv("SSL_CA_FILE")
app_name = os.getenv('KAFKA_APP_NAME')
api_app_name = os.getenv("APP_NAME")
task_name = os.getenv("KAFKA_PRODUCER_TASK")
api_task_name = os.getenv('AXIOM_SEC_TASK_NAME')
dag_ref = os.getenv("DAG_REF")
node_name = os.getenv("NODE_NAME")

def fetch_kafka_topic(task_id: int) -> Union[List[Dict[str, str]], None]:
    """Read producer configuration mappings from the kafka_producer_config table."""
    logger.info(f"{logger_prefix} Fetching Kafka config for task_id : {task_id}")

    try:
        sql = f"SELECT topic_name, file_pattern, client_id, source_ref, data_source FROM kafka_producer_config WHERE task_id = {task_id}"
        logger.info(f"{logger_prefix} Executing sql : {sql}")
        rows = exec_sql(sql)

        if rows:
            result = [{"topic": x[0], "file_pattern": x[1], "client_id": x[2], "source_ref": x[3]} for x in rows]
            return result
        else:
            return None
    except Exception as e:
        logger.error(f"{logger_prefix} Error on fetch_kafka_topic for task_id : {task_id}.")
        raise RuntimeError(f"Error on fetch_kafka_topic for task_id : {task_id} as {e}")


def kafka_config_params(client_id: str) -> Union[Dict[str, str], None]:
    """Fetch generic Kafka client parameters from the DB."""

    try:
        sql = f"SELECT config_name, config_details FROM kafka_config_params WHERE client_id = '{client_id}' and is_active = 'Y'"
        logger.info(f"{logger_prefix} Executing sql : {sql}")
        rows = exec_sql(sql)
        if rows:
            result = {str(row[0]).lower(): row[1] for row in rows}
            return result
        else:
            return None
    except Exception as e:
        logger.error(f"{logger_prefix} Error on kafka_config_params for client_id : {client_id}.")
        raise RuntimeError(f"Error on kafka_config_params for client_id : {client_id} as {e}.")


def fetch_completed_file(dag_ref: str, source_table: str, bus_date: str) -> Union[List[str], None]:
    """Return a list of files whose status is completed for the given run_id_timestamp"""

    logger.info(f"{logger_prefix} Checking for latest completed file...")

    try:
        ts_instance = dbm.get_task_instance(api_app_name, api_task_name, dag_ref)

        sql = f"SELECT DISTINCT output_shared_file, output_status FROM {source_table} WHERE task_instance = {ts_instance} AND business_date = TO_DATE('{bus_date}', 'YYYYMMDD')"
        logger.info(f"{logger_prefix} Executing sql : {sql} ")
        rows = exec_sql(sql)
        if not rows:
            logger.info(f"{logger_prefix} No record found for task_instance : {ts_instance} on business_date : {bus_date} on {source_table} table.")
            return None

        files = []
        for file_path, status in rows:
            status = status.lower()
            if status == "completed":
                files.append(file_path)
            elif status == "error":
                raise RuntimeError(f"Run status is failed for task_instance : {ts_instance} on business_date : {bus_date} on {source_table} table.")
            else:
                # still processing, let the caller retry
                return None
        return files
    except Exception as e:
        logger.error(f"{logger_prefix} Error occurred on fetch_completed_file for dag_ref : {dag_ref} on source table : {source_table} and bus_date : {bus_date}.")
        raise RuntimeError(f"Error occurred on fetch_completed_file for dag_ref : {dag_ref} on source table : {source_table} and bus_date : {bus_date} as {e}.") 


def get_files_with_retry(dag_ref: str, source_table: str, bus_date: str, max_retries: int, retry_interval: int) -> List[str]:
    """Poll the DB until the run is marked as completed or retries are exhausted."""
    for attempt in range(1, max_retries + 1):
        logger.info(f"{logger_prefix} Attempt {attempt}: checking output status")

        try:
            files = fetch_completed_file(dag_ref, source_table, bus_date)
        except Exception:
            raise RuntimeError(f"Output status marked as error from table : {source_table} for dag_ref : {dag_ref} for business_date : {bus_date}")

        if files is not None:
            return files

        logger.info(f"{logger_prefix} Not completed yet. Retrying after {retry_interval} seconds...")
        time.sleep(retry_interval)

    raise RuntimeError("Maximum retries exceeded while waiting for file completion")


def check_topic_exists(bootstrap_servers: str, topic: str, sasl_mechanism: str, security_protocol: str, request_timeout: int, metadata_max_age: int) -> bool:
    logger.info(f"{logger_prefix} Checking existence of topic: {topic}")

    try:
        # Create a temporary admin client with short timeout
        admin = KafkaAdminClient(
            bootstrap_servers=bootstrap_servers,
            security_protocol=security_protocol,
            sasl_mechanism=sasl_mechanism,
            sasl_plain_username=KAFKA_SASL_USERNAME,
            sasl_plain_password=KAFKA_SASL_PASSWORD,
            ssl_cafile=SSL_CA_FILE,
            request_timeout_ms=request_timeout,
            metadata_max_age_ms=metadata_max_age
        )

        # Force a metadata refresh by listing topics
        topics = admin.list_topics()
        logger.info(f"{logger_prefix} List of topic : {topics}")

        logger.info(f"{logger_prefix} closing KafkaAdminClient object for topic : {topic} checking.")
        admin.close()

        # Verify the specific topic exists
        if topic in topics:
            logger.info(f"{logger_prefix} Topic {topic} confirmed to exist")
            return True
        else:
            logger.info(f"{logger_prefix} Topic {topic} does not exist in cluster")
            return False

    except Exception as e:
        logger.error(f"{logger_prefix} Exception occurred checking topic existence: {str(e)}")
        admin.close()
        return False

def get_producer(bootstrap_servers: str, sasl_mechanism: str, security_protocol: str, acks: str, compression_type: str, retries: int, max_request_size: int, enable_idempotence: bool, client_id: str) -> KafkaProducer:
    """Return a configured, idempotent Producer."""
    logger.info(f"{logger_prefix} Creating KafkaProducer")

    try:
        prod = KafkaProducer(
            bootstrap_servers=bootstrap_servers,
            security_protocol=security_protocol,
            sasl_mechanism=sasl_mechanism,
            sasl_plain_username=KAFKA_SASL_USERNAME,
            sasl_plain_password=KAFKA_SASL_PASSWORD,
            ssl_cafile=SSL_CA_FILE,
            max_request_size=max_request_size, 
            enable_idempotence=enable_idempotence,
            acks=acks,
            retries=retries,
            compression_type=compression_type,
            client_id=client_id
        )
        logger.info(f"{logger_prefix} KafkaProducer ready")
        return prod
    except Exception as exc:
        logger.error(f"{logger_prefix} Failed to create producer: {exc}")
        raise RuntimeError(f"Failed to create producer: {exc}")

def build_key(task_id: int, filename: str, chunk_no: int, eof: bool) -> bytes:
    """
    Small JSON key that travels with every message.
    Keeping it tiny guarantees it never blows the request size limit.
    """
    key_dict = {
        "task_id": task_id,
        "file": os.path.basename(filename),
        "chunk": chunk_no,
        "eof": eof,
    }
    return json.dumps(key_dict).encode("utf-8")

def send_file_in_chunks(producer: KafkaProducer, topic: str, task_id: int, task_instance: int, bus_date: str, client_id: str, filepath: str, chunk_size: int, send_timeout: int) -> None:

    if not os.path.isfile(filepath):
        raise FileNotFoundError(f"File not found: {filepath}")

    logger.info(f"{logger_prefix} Streaming {filepath} data to producer topic : {topic}")

    first_offset = 0
    chunk_no = 0
    partition=0
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            chunk_no += 1
            eof = len(chunk) < chunk_size

            # Build key/value
            key = build_key(task_id, filepath, chunk_no, eof)
            print (f"key : {key}")

            # already bytes, no conversion
            value = chunk

            # Send synchronously so that we can catch RecordTooLargeError
            future = producer.send(topic, partition=partition, key=key, value=value)

            try:
                # .get() will raise if the broker rejected the record
                record_meta = future.get(timeout=send_timeout)
                if first_offset == 0:
                    dbm.update_producer_log(topic, task_instance, bus_date, client_id, 'processing', record_meta.offset, partition, filepath)
                    first_offset += 1

                if eof:
                    dbm.update_producer_log(topic, task_instance, bus_date, client_id, 'completed', record_meta.offset, partition, filepath)

                logger.info(f"{logger_prefix} Sent chunk {chunk_no} (bytes={len(chunk)}, eof={eof}) partition {record_meta.partition} offset {record_meta.offset}")
            except Exception as exc:
                logger.error(f"{logger_prefix} Failed to send chunk {chunk_no}: {exc}")
                dbm.update_producer_log(topic, task_instance, bus_date, client_id, 'error', record_meta.offset, partition, filepath)
                logger.info(f"{logger_prefix} Updated producer log for topic : {topic} and task_instance : {task_instance}.")
                raise RuntimeError(f" Failed to send chunk {chunk_no}: {exc}")

    logger.info(f"{logger_prefix} Finished streaming {filepath} (total {chunk_no} chunks)")


def _parse_kafka_cfg(kafka_cfg: dict) -> dict:
    """Extract and cast all Kafka config values. Raises RuntimeError if a key is missing."""
    try:
        return {
            "bootstrap_servers": kafka_cfg["bootstrap_servers"],
            "sasl_mechanism": kafka_cfg["sasl_mechanism"],
            "security_protocol": kafka_cfg["security_protocol"],
            "request_timeout": int(kafka_cfg["request_timeout"]),
            "acks": kafka_cfg["acks"],
            "compression_type": kafka_cfg["compression_type"],
            "retries": int(kafka_cfg["retries"]),
            "max_request_size": eval(kafka_cfg["max_request_size"]),
            "topic_chunk_size": eval(kafka_cfg["topic_chunk_size"]),
            "app_run_check_max_retries": int(kafka_cfg["app_run_check_max_retries"]),
            "app_run_check_retry_interval": int(kafka_cfg["app_run_check_retry_interval"]),
            "enable_idempotence": bool(kafka_cfg["enable_idempotence"]),
            "metadata_max_age_ms": int(kafka_cfg["metadata_max_age_ms"]),
            "producer_send_timeout": int(kafka_cfg["producer_send_timeout"]),
        }
    except Exception as e:
        raise RuntimeError(f"Kafka config params value not available : {e}")


def _find_matched_file(completed_files: list, cfg: dict) -> str:
    """Return the first file path matching the configured file pattern."""
    pattern = cfg["file_pattern"].strip().lower()
    for file_path in completed_files:
        file_name = os.path.basename(file_path)
        logger.info(f"{logger_prefix} Trying match : file='{file_name.lower()}'  pattern='{pattern}'")
        if fnmatch.fnmatch(file_name.lower(), pattern):
            logger.info(f"{logger_prefix} Matched file {file_name} for topic {cfg['topic']} (pattern={cfg['file_pattern']})")
            return file_path
    raise RuntimeError(f"No file mapping found in completed files for file pattern : {cfg['file_pattern']} on table {cfg['source_ref']}")


def _process_topic(cfg: dict, task_id: int, ts_instance: int, business_date: tuple) -> None:
    """Handle the full producer flow for a single Kafka topic config entry."""
    kafka_cfg_raw = kafka_config_params(cfg.get("client_id"))
    if not kafka_cfg_raw:
        raise RuntimeError(f"No Kafka configuration found for client_id : {cfg.get('client_id')} on table kafka_config_params.")

    logger.info(f"{logger_prefix} Kafka config params : {kafka_cfg_raw}")
    kc = _parse_kafka_cfg(kafka_cfg_raw)

    completed_files = get_files_with_retry(
        dag_ref, cfg.get("source_ref"), business_date[1],
        kc["app_run_check_max_retries"], kc["app_run_check_retry_interval"]
    )
    logger.info(f"{logger_prefix} Total {len(completed_files)} completed files for dag_ref : {dag_ref}")

    if not check_topic_exists(kc["bootstrap_servers"], cfg["topic"], kc["sasl_mechanism"],
                              kc["security_protocol"], kc["request_timeout"], kc["metadata_max_age_ms"]):
        raise RuntimeError(f"Topic {cfg['topic']} does not exist or Kafka Admin Client exception occurred.")

    producer = get_producer(
        kc["bootstrap_servers"], kc["sasl_mechanism"], kc["security_protocol"],
        kc["acks"], kc["compression_type"], kc["retries"],
        kc["max_request_size"], kc["enable_idempotence"], cfg.get("client_id")
    )

    try:
        file_path = _find_matched_file(completed_files, cfg)
        send_file_in_chunks(
            producer, cfg["topic"], task_id, ts_instance,
            business_date[1], cfg["client_id"], file_path,
            kc["topic_chunk_size"], kc["producer_send_timeout"]
        )
    except Exception as e:
        producer.flush()
        producer.close()
        logger.info(f"{logger_prefix} Producer closed for topic {cfg['topic']} due to : {str(e)}.")
        raise RuntimeError(f"Producer closed during topic {cfg['topic']} : {str(e)}.")

    producer.flush()
    producer.close()


# ------------------------------------------------------------------
#  MAIN workflow
# ------------------------------------------------------------------
def main() -> None:
    global logger_prefix
    try:
        if not task_name or not app_name or not dag_ref:
            raise RuntimeError("task_name or app_name or dag_ref cannot be empty. Environment variables not set.")

        business_date = dbm.get_app_business_date(api_app_name)
        run_mode = str(dag_ref).split('__')[0].split('-')[1]

        dbm.update_ts_task_status(app_name, task_name, business_date[1], dag_ref, run_mode, 'processing', 'processing producer')
        ts_instance = dbm.get_task_instance(app_name, task_name, dag_ref)
        logger_prefix = f"[{ts_instance}] [{node_name}]"

        logger.info(f"{logger_prefix} Starting Kafka Producer script")
        task_id = dbm.get_task_id(api_app_name, api_task_name)
        logger.info(f"{logger_prefix} task_id : {task_id}, dag_ref : {dag_ref}, business_date : {business_date[1]}")

        kafka_topics = fetch_kafka_topic(task_id)
        if not kafka_topics:
            raise RuntimeError(f"No Kafka topic found for task_id : {task_id} and business_date : {business_date[1]}")

        logger.info(f"{logger_prefix} Kafka producer config : {kafka_topics}")

        for cfg in kafka_topics:
            dbm.update_producer_log(cfg['topic'], ts_instance, business_date[1], cfg['client_id'], 'processing')
            _process_topic(cfg, task_id, ts_instance, business_date)

        dbm.update_ts_task_status(app_name, task_name, business_date[1], dag_ref, run_mode, 'completed', 'producer completed')
        sys.exit(0)

    except Exception as e:
        logger.error(f"{logger_prefix} Error in main function: {str(e)}", exc_info=True)
        dbm.update_ts_task_status(app_name, task_name, business_date[1], dag_ref, run_mode, 'error', 'error')
        dbm.update_producer_log(cfg['topic'], ts_instance, business_date[1], cfg['client_id'], 'error')
        sys.exit(1)
