#!/usr/bin/env python3
"""
update_yaml_push.py
Stage  : Update YAML Files And Push Changes
Purpose: For each built image, sed-replace the old image tag with the new one in
         the pod template files listed in image-config.yml. Then commit and push
         version.yml + infra/airflow/dags/ to the Jira branch.

         The sed pattern matches the full Artifactory image path so only the
         version suffix is replaced, leaving the rest intact.

Reads env vars:
  ACTUAL_BRANCH        - Jira branch name (e.g. CZUNISRC-53)
  IMAGES_TO_BUILD      - comma-separated image names
  BUILD_<IMAGE>        - YES / NO per image
  <IMAGE>_IMAGE_TAG    - new tag for each built image
  ARTI_REPO_DEV        - dev Artifactory repo name
  ARTIFACTORY_REGISTRY - Artifactory hostname
  DOCKER_REPO_PATH     - base Docker image path
  VERSION_FILE         - relative path to version.yml
  WORKSPACE            - Jenkins workspace root
  SSH_KEY              - path to SSH private key (injected by withCredentials)

Emits (KEY=VALUE line at the very end of stdout):
  YAML_PUSH_STATUS=pushed | skipped | no_changes
"""

import os
import re
import subprocess
import sys

import yaml

sys.stdout.reconfigure(line_buffering=True)


def run_cmd(cmd, capture_output=False, check=True, env=None):
    merged = os.environ.copy()
    if env:
        merged.update(env)
    result = subprocess.run(
        cmd, shell=True, capture_output=capture_output, text=True, env=merged
    )
    if check and result.returncode != 0:
        raise RuntimeError(
            f"Command failed (exit {result.returncode}): {cmd}\n{result.stderr}"
        )
    return result.stdout.strip() if capture_output else None


def load_image_config():
    workspace = os.getenv("WORKSPACE", os.getcwd())
    path = os.path.join(workspace, "jenkins", "image-config.yml")
    if not os.path.isfile(path):
        raise FileNotFoundError(f"image-config.yml not found at {path}")
    with open(path) as f:
        return yaml.safe_load(f)


def update_templates(images_cfg, actual_branch):
    arti_repo     = os.getenv("ARTI_REPO_DEV", "unidata-docker-local-dev")
    arti_registry = os.getenv("ARTIFACTORY_REGISTRY", "artifactory.cib.echonet")
    docker_repo   = os.getenv("DOCKER_REPO_PATH", "unisrc/testdockerimages")
    branch_lower  = actual_branch.lower()

    for image_name, config in images_cfg.items():
        build_flag = os.getenv(f"BUILD_{image_name.upper()}", "NO").strip()
        if build_flag != "YES":
            continue

        new_tag   = os.getenv(f"{image_name.upper()}_IMAGE_TAG", "").strip()
        templates = config.get("templates") or []

        if not templates:
            print(f"No templates configured for '{image_name}' — skipping sed.", flush=True)
            continue
        if not new_tag:
            sys.stderr.write(f"No image tag found for '{image_name}' — cannot update templates.\n")
            sys.exit(1)

        for template_file in templates:
            workspace = os.getenv("WORKSPACE", os.getcwd())
            filepath  = os.path.join(workspace, template_file)
            if not os.path.isfile(filepath):
                sys.stderr.write(f"Template file not found: {filepath}\n")
                sys.exit(1)

            # Matches full Artifactory path with any existing version suffix
            old_pattern = (
                rf"{re.escape(arti_repo)}\.{re.escape(arti_registry)}/"
                rf"{re.escape(docker_repo)}/releases/{re.escape(branch_lower)}"
                rf":{re.escape(image_name)}_[0-9][0-9.]*"
            )
            new_value = (
                f"{arti_repo}.{arti_registry}/"
                f"{docker_repo}/releases/{branch_lower}"
                f":{image_name}_{new_tag}"
            )

            print(f"Updating '{image_name}' → '{new_tag}' in {template_file}", flush=True)
            run_cmd(f"""sed -r -i "s#{old_pattern}#{new_value}#g" "{filepath}" """)

            # Verify replacement applied (mirrors Groovy grep check)
            with open(filepath) as f:
                content = f.read()
            if f"{image_name}_{new_tag}" not in content:
                sys.stderr.write(
                    f"Template update failed for {template_file} — "
                    f"'{image_name}_{new_tag}' not found after sed. "
                    f"Check the image path pattern in the file.\n"
                )
                sys.exit(1)

            print(f"  ✓ Verified '{image_name}_{new_tag}' present in {template_file}", flush=True)


def git_commit_and_push(actual_branch, version_file):
    ssh_key = os.getenv("SSH_KEY", "").strip()
    # git_env passed to ALL git commands so SSH key is always honoured
    git_env = {"GIT_SSH_COMMAND": f"ssh -i {ssh_key} -o StrictHostKeyChecking=no"} if ssh_key else {}

    # Check for any working tree changes (mirrors Groovy: git status --porcelain)
    status = run_cmd("git status --porcelain", capture_output=True, check=False)
    if not status:
        print("No changes to push", flush=True)
        print("YAML_PUSH_STATUS=no_changes", flush=True)
        return

    run_cmd(f"git checkout {actual_branch}", env=git_env)
    # git config and git add must also use git_env so SSH works for any git op
    run_cmd('git config user.email "jenkins@bnpparibas.com"', env=git_env)
    run_cmd('git config user.name "Jenkins"', env=git_env)
    run_cmd(f"git add {version_file} infra/airflow/dags/", env=git_env)

    # Check staged diff before committing (mirrors Groovy: git diff --cached --quiet)
    diff_result = subprocess.run(
        "git diff --cached --quiet",
        shell=True, capture_output=True,
        env={**os.environ, **git_env}
    )
    if diff_result.returncode == 0:
        # exit 0 means no staged changes
        print("No template changes detected — skipping commit", flush=True)
        print("YAML_PUSH_STATUS=skipped", flush=True)
        return

    run_cmd(
        'git commit -m "Auto update jira image versions via jenkins pipeline [skip ci]"',
        env=git_env,
    )
    run_cmd(f'git rebase "origin/{actual_branch}"', env=git_env)
    run_cmd(f'git push origin "{actual_branch}"', env=git_env)
    print(f"Version and YAML updates pushed to {actual_branch}", flush=True)
    print("YAML_PUSH_STATUS=pushed", flush=True)


def main():
    required = ["ACTUAL_BRANCH", "IMAGES_TO_BUILD"]
    missing = [v for v in required if not os.getenv(v)]
    if missing:
        sys.stderr.write(f"Missing required env vars: {', '.join(missing)}\n")
        sys.exit(1)

    actual_branch = os.getenv("ACTUAL_BRANCH").strip()
    version_file  = os.getenv("VERSION_FILE", "jenkins/version.yml").strip()

    image_cfg = load_image_config()
    update_templates(image_cfg.get("images", {}), actual_branch)
    git_commit_and_push(actual_branch, version_file)
    # YAML_PUSH_STATUS is printed inside git_commit_and_push as the last line


if __name__ == "__main__":
    main()
