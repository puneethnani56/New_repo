#!/usr/bin/env python3
"""
bump_versions.py
Stage  : Bump Versions
Purpose: Read version.yml, bump the version for each image in IMAGES_TO_BUILD
         under the 'jira.images' section according to RELEASE_TYPE (PATCH/MINOR/MAJOR).
         Write the updated version.yml back in place, preserving key order and
         comments using ruamel.yaml round-trip loader.

Reads env vars:
  IMAGES_TO_BUILD  - comma-separated list of image names to bump
  RELEASE_TYPE     - PATCH | MINOR | MAJOR
  VERSION_FILE     - relative path to version.yml (default: jenkins/version.yml)
  WORKSPACE        - Jenkins workspace root
  BUILD_<IMAGE>    - YES / NO per image (only bumps images where BUILD_<IMAGE>=YES)

Emits (KEY=VALUE lines at the very end of stdout):
  <IMAGE>_IMAGE_TAG=<newTag>  - one per bumped image
  IMAGE_TAGS=<img>:<tag>,...  - comma-separated image:tag pairs
"""

import os
import sys

sys.stdout.reconfigure(line_buffering=True)

try:
    from ruamel.yaml import YAML
except ImportError:
    sys.stderr.write("ruamel.yaml is not installed. Run: pip install ruamel.yaml\n")
    sys.exit(1)


def bump_version(current: str, release_type: str) -> str:
    parts = current.strip().split(".")
    while len(parts) < 3:
        parts.append("0")
    try:
        maj, min_, pat = int(parts[0]), int(parts[1]), int(parts[2])
    except ValueError:
        raise ValueError(f"Cannot parse version '{current}' — expected MAJOR.MINOR.PATCH format")

    if release_type == "MAJOR":
        if maj >= 99:
            raise RuntimeError("MAJOR version already at max (99). Reset manually.")
        maj += 1; min_ = 0; pat = 0
    elif release_type == "MINOR":
        if min_ >= 99:
            raise RuntimeError("MINOR version already at max (99). Reset manually.")
        min_ += 1; pat = 0
    elif release_type == "PATCH":
        if pat >= 99:
            raise RuntimeError("PATCH at max.")
        pat += 1
    else:
        raise ValueError(f"Unsupported RELEASE_TYPE: '{release_type}'")

    return f"{maj}.{min_}.{pat}"


def main():
    required = ["IMAGES_TO_BUILD", "RELEASE_TYPE"]
    missing = [v for v in required if not os.getenv(v)]
    if missing:
        sys.stderr.write(f"Missing required env vars: {', '.join(missing)}\n")
        sys.exit(1)

    workspace       = os.getenv("WORKSPACE", os.getcwd())
    version_file    = os.getenv("VERSION_FILE", "jenkins/version.yml")
    version_path    = os.path.join(workspace, version_file)
    release_type    = os.getenv("RELEASE_TYPE").strip().upper()
    images_to_build = [
        i.strip() for i in os.getenv("IMAGES_TO_BUILD", "").split(",") if i.strip()
    ]

    if not os.path.isfile(version_path):
        sys.stderr.write(f"version.yml not found at {version_path}\n")
        sys.exit(1)

    # ruamel.yaml round-trip: preserves key order, comments, and formatting
    ryaml = YAML()
    ryaml.preserve_quotes = True
    with open(version_path) as f:
        data = ryaml.load(f)

    jira_images = data.get("jira", {}).get("images", {})
    if not jira_images:
        sys.stderr.write("version.yml is missing 'jira.images' section\n")
        sys.exit(1)

    image_tags = []  # "imageName:newTag" — for IMAGE_TAGS env var
    kv_lines   = []  # KEY=VALUE lines collected and emitted last

    for image_name in images_to_build:
        build_flag = os.getenv(f"BUILD_{image_name.upper()}", "NO").strip()
        if build_flag != "YES":
            print(f"Build disabled for '{image_name}' — skipping.", flush=True)
            continue

        image_info = jira_images.get(image_name)
        if not image_info or not image_info.get("latest"):
            sys.stderr.write(
                f"No version entry for '{image_name}' in jira.images of {version_file}\n"
            )
            sys.exit(1)

        current_tag = str(image_info["latest"]).strip()
        try:
            new_tag = bump_version(current_tag, release_type)
        except (RuntimeError, ValueError) as e:
            sys.stderr.write(f"Version bump failed for '{image_name}': {e}\n")
            sys.exit(1)

        existing_versions = list(image_info.get("versions", []) or [])
        image_info["latest"]   = new_tag
        image_info["versions"] = ([new_tag] + existing_versions)[:7]  # keep last 7

        print(
            f"'{image_name}' bumped: {current_tag} → {new_tag} | "
            f"versions: {list(image_info['versions'])}",
            flush=True,
        )
        image_tags.append(f"{image_name}:{new_tag}")
        kv_lines.append(f"{image_name.upper()}_IMAGE_TAG={new_tag}")

    # Write updated version.yml — ruamel preserves key order and comments
    with open(version_path, "w") as f:
        ryaml.dump(data, f)

    # Mirror Groovy's: sh "cat ${env.VERSION_FILE}"
    print(f"\n----- Updated {version_file} -----", flush=True)
    with open(version_path) as f:
        print(f.read(), flush=True)

    # ── KEY=VALUE block — must be last output ─────────────────────────────
    print("=== KEY=VALUE block for Jenkins readProperties ===", flush=True)
    for line in kv_lines:
        print(line, flush=True)
    print(f"IMAGE_TAGS={','.join(image_tags)}", flush=True)


if __name__ == "__main__":
    main()
