#!/usr/bin/env python3
#added comment 3
import os
import sys
import subprocess
import json

sys.stdout.reconfigure(line_buffering=True)

def run_cmd(cmd, env=None, cwd=None, capture_output=False, check=True):
    result = subprocess.run(
        cmd,
        shell=True,
        cwd=cwd,
        env=env or os.environ.copy(),
        capture_output=capture_output,
        text=True,
    )
    if check and result.returncode != 0:
        raise RuntimeError(f"Command failed (exit {result.returncode}): {cmd}\n{result.stderr}")
    return result.stdout.strip() if capture_output else None

def main():
    required_vars = [
        "BITBUCKET_API_URL",
        "BITBUCKET_TOKEN",
        "PROJECT_KEY",
        "REPO_NAME",
        "BRANCH_NAME",
        "SIT_BRANCH",
    ]
    missing = [v for v in required_vars if v not in os.environ]
    if missing:
        sys.stderr.write(f"Missing required environment variables: {', '.join(missing)}\n")
        sys.exit(1)

    api_url = os.getenv("BITBUCKET_API_URL")
    token = os.getenv("BITBUCKET_TOKEN")
    project_key = os.getenv("PROJECT_KEY")
    repo_name = os.getenv("REPO_NAME")
    target_branch = os.getenv("SIT_BRANCH")
    
    source_branch = os.getenv("ACTUAL_BRANCH") or os.getenv("BRANCH_NAME")
    if not source_branch:
        sys.stderr.write("Missing ACTUAL_BRANCH or BRANCH_NAME environment variable .\n")
        sys.exit(1)

    os.environ["CURRENT_STAGE"] = "Bitbucket PR for SIT branch"
    print(f"[Bitbucket PR] Starting PR creation from '{source_branch}' to '{target_branch}' (source -> target)", flush=True)
    # Check for existing open PRs from JIRA_BRANCH to sit_branch
    list_prs_url = (
        f"{api_url}/rest/api/1.0/projects/{project_key}/repos/{repo_name}/pull-requests"
        f"?state=OPEN&at=refs/heads/{source_branch}"
    )
    curl_cmd = (
        f"curl -s -H 'Authorization: Bearer {token}' "
        f"-H 'Content-Type: application/json' "
        f"'{list_prs_url}'"
    )
    try:
        response = run_cmd(curl_cmd, capture_output=True)
        data = json.loads(response)
        # Find PR where fromRef.id matches jira_branch and toRef.id matches sit_branch
        existing = None
        for pr in data.get('values', []):
            from_ref = pr.get('fromRef', {}).get('id')
            to_ref = pr.get('toRef', {}).get('id')
            if from_ref == f"refs/heads/{source_branch}" and to_ref == f"refs/heads/{target_branch}":
                existing = pr
                break
        if existing:
            pr_id = existing.get('id')
            print(f"Existing PR found: {pr_id}", flush=True)
            print(f"PR_ID={pr_id}", flush=True)
            return
    except Exception as e:
        sys.stderr.write(f"Failed to query existing PRs: {e}\n")
        sys.exit(1)

# No existing PR, create a new one
    create_pr_url = (
        f"{api_url}/rest/api/1.0/projects/{project_key}/repos/{repo_name}/pull-requests"
    )
    payload = {
        "title": f"Auto PR: {source_branch} to {target_branch}",
        "description": "Automated PR created by Jenkins pipeline",
        "state": "OPEN",
        "open": True,
        "closed": False,
        "fromRef": {
            "id": f"refs/heads/{source_branch}",
            # slug must match Bitbucket repo slug exactly (case-sensitive).
            # Groovy hardcodes "UNISRC" — read from REPO_SLUG env if overridden.
            "repository": {"slug": os.getenv("REPO_SLUG", "UNISRC"), "project": {"key": project_key}}
        },
        "toRef": {
            "id": f"refs/heads/{target_branch}",
            "repository": {"slug": os.getenv("REPO_SLUG", "UNISRC"), "project": {"key": project_key}}
        },
        "reviewers": []
    }

    payload_str = json.dumps(payload)
    curl_create = (
        f"curl -s -X POST -H 'Authorization: Bearer {token}' "
        f"-H 'Content-Type: application/json' "
        f"-d '{payload_str}' "
        f"'{create_pr_url}'"
    )
    try:
        create_resp = run_cmd(curl_create, capture_output=True)
        pr_data = json.loads(create_resp)

        if "errors" in pr_data:
            # Look for the duplicate‑PR error and extract the existing PR id
            dup_err = next(
                (e for e in pr_data["errors"]
                 if e.get("exceptionName") == "com.atlassian.bitbucket.pull.DuplicatePullRequestException"),
                None,
            )
            if dup_err and "existingPullRequest" in dup_err:
                existing_id = dup_err["existingPullRequest"]["id"]
                print(f"Existing PR detected – reusing existing PR #{existing_id}", flush=True)
                print(f"PR_ID={existing_id}", flush=True)
                sys.exit(0)
            else:
                raise RuntimeError(f"PR creation failed: {pr_data}")

        # Normal success path
        pr_id = pr_data.get("id") or pr_data.get("pullRequestId")
        if pr_id is None:
            raise RuntimeError(f"PR creation response missing id. Response: {pr_data}")
        print(f"Created New PR with id: {pr_id}", flush=True)
        print(f"PR_ID={pr_id}", flush=True)

    except Exception as e:
        sys.stderr.write(f"Failed to create PR: {e}\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
