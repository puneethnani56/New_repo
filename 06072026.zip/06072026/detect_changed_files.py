#!/usr/bin/env python3
"""
detect_changed_files.py
Stage  : Detect Changed Files
Purpose: Compare current commit against the previous successful build's GIT_COMMIT
         using git diff. Falls back to Jenkins changeSets via CHANGED_FILES_FALLBACK
         env var (comma-separated list written by Groovy before calling this script).
         Resolves image dependencies and topological build order.

Emits (KEY=VALUE lines, captured by Jenkins readProperties):
  CHANGED_FILES   - comma-separated list of changed file paths
  IMAGES_TO_BUILD - comma-separated build-ordered image names
  SKIP_BUILD      - true / false
  BUILD_<IMAGE>   - YES / NO  (one per image in image-config.yml)
"""

import os
import sys
import subprocess
import yaml

sys.stdout.reconfigure(line_buffering=True)


def run_cmd(cmd, capture_output=False, check=True):
    result = subprocess.run(cmd, shell=True, capture_output=capture_output, text=True)
    if check and result.returncode != 0:
        raise RuntimeError(f"Command failed (exit {result.returncode}): {cmd}\n{result.stderr}")
    return result.stdout.strip() if capture_output else None


def load_image_config():
    workspace = os.getenv("WORKSPACE", os.getcwd())
    path = os.path.join(workspace, "jenkins", "image-config.yml")
    if not os.path.isfile(path):
        raise FileNotFoundError(f"image-config.yml not found at {path}")
    with open(path) as f:
        cfg = yaml.safe_load(f)
    if not cfg or "images" not in cfg:
        raise ValueError("No 'images' section found in image-config.yml")
    return cfg["images"]


def get_changed_files():
    """
    Primary  : git diff between PREV_SUCCESSFUL_COMMIT and GIT_COMMIT.
    Fallback : CHANGED_FILES_FALLBACK env var (comma-separated), written by Groovy
               from currentBuild.changeSets when no previous successful commit exists.
    """
    current_commit  = os.getenv("GIT_COMMIT", "").strip()
    previous_commit = os.getenv("PREV_SUCCESSFUL_COMMIT", "").strip()

    changed = set()

    if previous_commit and current_commit and previous_commit != current_commit:
        print(f"Previous successful commit : {previous_commit}", flush=True)
        print(f"Current commit             : {current_commit}", flush=True)
        try:
            raw = run_cmd(
                f"git diff --name-only {previous_commit} {current_commit}",
                capture_output=True,
            )
            if raw:
                changed.update(f for f in raw.splitlines() if f.strip())
                print(f"Changed files from git diff: {len(changed)}", flush=True)
        except RuntimeError as e:
            print(f"Warning: git diff failed — {e}. Falling back.", flush=True)

    if not changed:
        fallback = os.getenv("CHANGED_FILES_FALLBACK", "").strip()
        fallback_meta = os.getenv("CHANGED_FILES_FALLBACK_META", "").strip()
        if fallback:
            print("Falling back to Jenkins changeSets", flush=True)
            # CHANGED_FILES_FALLBACK_META contains pipe-delimited commit entries:
            # commitId|author|message  (one per line, written by Groovy)
            if fallback_meta:
                for entry in fallback_meta.split("\n"):
                    parts = entry.split("|")
                    if len(parts) >= 3:
                        print("--------------------------------------------------", flush=True)
                        print(f"Commit ID : {parts[0]}", flush=True)
                        print(f"Author    : {parts[1]}", flush=True)
                        print(f"Message   : {parts[2]}", flush=True)
                        print("--------------------------------------------------", flush=True)
            changed.update(f for f in fallback.split(",") if f.strip())
        else:
            print("No changed files detected from any source.", flush=True)

    return sorted(changed)


def detect_images_to_build(images_cfg, changed_files):
    """Match changed files against trigger paths; add dependencies; resolve build order."""
    triggered = []
    for image_name, config in images_cfg.items():
        triggers = config.get("triggers", [])
        if not triggers:
            print(f"Warning: no triggers defined for image '{image_name}'", flush=True)
            continue
        if any(
            changed_file.startswith(trigger)
            for changed_file in changed_files
            for trigger in triggers
        ):
            triggered.append(image_name)
            print(f"[MATCH] '{image_name}' triggered by file change", flush=True)

    # Dependency expansion
    changed = True
    while changed:
        changed = False
        for image_name, config in images_cfg.items():
            deps = config.get("depends_on", []) or []
            if image_name not in triggered and any(d in triggered for d in deps):
                triggered.append(image_name)
                changed = True
                print(f"[DEPENDENCY] '{image_name}' added (depends on triggered image)", flush=True)

    # Topological sort (dependencies first)
    ordered = []
    visited = set()

    def visit(name):
        if name in visited:
            return
        visited.add(name)
        for dep in (images_cfg[name].get("depends_on") or []):
            if dep in triggered:
                visit(dep)
        ordered.append(name)

    for name in triggered:
        visit(name)

    return ordered


def main():
    required = ["GIT_COMMIT"]
    missing = [v for v in required if not os.getenv(v)]
    if missing:
        sys.stderr.write(f"Missing required env vars: {', '.join(missing)}\n")
        sys.exit(1)

    images_cfg   = load_image_config()
    changed_files = get_changed_files()

    print("\n=== Changed Files ===", flush=True)
    if changed_files:
        for f in changed_files:
            print(f"  {f}", flush=True)
    else:
        print("  (none)", flush=True)

    images_to_build = detect_images_to_build(images_cfg, changed_files)

    print("\n=== Build Order ===", flush=True)
    if images_to_build:
        for i, name in enumerate(images_to_build, 1):
            print(f"  {i}. {name}", flush=True)
    else:
        print("  (none — SKIP_BUILD=true)", flush=True)

    skip_build = "true" if not images_to_build else "false"

    # ── KEY=VALUE block — emitted last, after all human-readable log output ──
    # readProperties in Groovy ignores non KEY=VALUE lines (treats them as
    # comments), but keeping them at the end avoids any ambiguity.
    print("\n=== KEY=VALUE block for Jenkins readProperties ===", flush=True)
    print(f"CHANGED_FILES={','.join(changed_files)}", flush=True)
    print(f"IMAGES_TO_BUILD={','.join(images_to_build)}", flush=True)
    print(f"SKIP_BUILD={skip_build}", flush=True)
    for image_name in images_cfg:
        flag = "YES" if image_name in images_to_build else "NO"
        print(f"BUILD_{image_name.upper()}={flag}", flush=True)


if __name__ == "__main__":
    main()
