#!/usr/bin/env python3

import os
import subprocess
import sys

sys.stdout.reconfigure(line_buffering=True)
def run_cmd(cmd, env=None):
    """Run a shell command, streaming stdout/stderr.
    ``env`` merges the current environment with any overrides.
    """
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    result = subprocess.run(cmd, shell=True, env=merged_env)
    if result.returncode != 0:
        raise RuntimeError(f"Command failed with exit code {result.returncode}: {cmd}")

def main():
    required_vars = [
        "SONARQUBE_SERVER",
        "SONARQUBE_PROJECT_KEY",
        "SONARQUBE_PROJECT_NAME",
        "SONARQUBE_PROJECT_VERSION",
        "ACTUAL_BRANCH",
        "SONAR_HOST_URL",
    ]
    missing = [v for v in required_vars if v not in os.environ]
    if missing:
        sys.stderr.write(f"Missing required environment variables: {', '.join(missing)}\n")
        sys.exit(1)

    sonar_scanner_path = os.getenv(
        "SONAR_SCANNER_PATH",
        "/mnt/apps/sonar-scanner-cli/7.1.0.4889/bin/sonar-scanner",
    )
    sonar_cmd = (
        "set -x && "
        "export SONAR_SCANNER_OPTS='-Xmx1048m' && "
        f"{sonar_scanner_path} "
        "-Dsonar.sources=. "
        "-Dsonar.scm.provider=git "
        f"-Dsonar.projectKey={os.getenv('SONARQUBE_PROJECT_KEY')} "
        f"-Dsonar.projectName={os.getenv('SONARQUBE_PROJECT_NAME')} "
        f"-Dsonar.projectVersion={os.getenv('SONARQUBE_PROJECT_VERSION')} "
        f"-Dsonar.branch.name={os.getenv('ACTUAL_BRANCH') or os.getenv('BRANCH_NAME')} "
        "-Dsonar.python.version=3 "
        f"-Dsonar.host.url={os.getenv('SONAR_HOST_URL')} "
        "-Dsonar.cpd.minimumLines=10000 "
        "-Dsonar.cpd.minimumTokens=50000 "
        "-Dsonar.exclusions=apps/bloomberg/Dockerfile,utility/roll_business_date/Dockerfile"
    )

    try:
        run_cmd(sonar_cmd)
    except RuntimeError as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
