#!/usr/bin/env python3

import os
import sys
import subprocess
import json
import tempfile
import shutil

sys.stdout.reconfigure(line_buffering=True)

def run_cmd(cmd, env=None, cwd=None, capture_output=False, check=True):
    result = subprocess.run(
        cmd,
        shell=True,
        cwd=cwd,
        env=env or os.environ.copy(),
        capture_output=capture_output,
        text=True,
    )
    if check and result.returncode != 0:
        raise RuntimeError(f"Command failed (exit {result.returncode}): {cmd}\n{result.stderr}")
    return result.stdout.strip() if capture_output else None

def main():
    required_vars = [
        "BITBUCKET_API_URL",
        "BITBUCKET_TOKEN",
        "PROJECT_KEY",
        "REPO_NAME",
        "SIT_BRANCH",
        "REPO_SSH_URL",
    ]
    missing = [v for v in required_vars if v not in os.environ]
    if missing:
        sys.stderr.write(f"Missing required environment variables: {', '.join(missing)}\n")
        sys.exit(1)

    bitbucket_api = os.getenv("BITBUCKET_API_URL")
    token = os.getenv("BITBUCKET_TOKEN")
    project_key = os.getenv("PROJECT_KEY")
    repo_name = os.getenv("REPO_NAME")
    sit_branch = os.getenv("SIT_BRANCH")
    repo_ssh = os.getenv("REPO_SSH_URL")

    os.environ["CURRENT_STAGE"] = "Create SIT Branch"
    print(f"[Create SIT Branch] Starting stage for branch '{sit_branch}'", flush=True)

    api_url = f"{bitbucket_api}/rest/api/1.0/projects/{project_key}/repos/{repo_name}/branches?filterText={sit_branch}"
    curl_cmd = (
        f"curl -s -H 'Authorization: Bearer {token}' "
        f"-H 'Content-Type: application/json' "
        f"'{api_url}'"
    )
    try:
        response = run_cmd(curl_cmd, capture_output=True)
        data = json.loads(response)
        existing = any(branch.get('displayId') == sit_branch for branch in data.get('values', []))
    except Exception as e:
        sys.stderr.write(f"Failed to query Bitbucket API: {e}\n")
        sys.exit(1)

    if existing:
        print(f"Branch '{sit_branch}' already exists. Skipping creation.", flush=True)
        return

    print(f"Branch '{sit_branch}' not found. Creating it now.", flush=True)


    temp_dir = tempfile.mkdtemp(prefix="sit_branch_")
    try:
        run_cmd("mkdir -p ~/.ssh && ssh-keyscan -p 7999 bitbucket.cib.echonet >> ~/.ssh/known_hosts")
        # Use injected SSH_KEY (from Jenkins withCredentials sshUserPrivateKey)
        # Falls back to agent-forwarded key (sshagent) if SSH_KEY is not set.
        ssh_key = os.getenv("SSH_KEY", "").strip()
        git_ssh_cmd = (
            f"ssh -i {ssh_key} -o StrictHostKeyChecking=no"
            if ssh_key else
            "ssh -o StrictHostKeyChecking=no"
        )
        env = os.environ.copy()
        env["GIT_SSH_COMMAND"] = git_ssh_cmd
        run_cmd(f"git clone {repo_ssh} .", cwd=temp_dir, env=env)
        run_cmd("git checkout master", cwd=temp_dir, env=env)
        run_cmd("git pull origin master", cwd=temp_dir, env=env)
        run_cmd(f"git checkout -b {sit_branch}", cwd=temp_dir, env=env)
        readme_path = os.path.join(temp_dir, "README.md")
        with open(readme_path, "w") as f:
            f.write(sit_branch)
        run_cmd("git add README.md", cwd=temp_dir, env=env)
        # Use double quotes so the shell receives unquoted values
        run_cmd('git config user.email "jenkins@bnpparibas.com"', cwd=temp_dir, env=env)
        run_cmd('git config user.name "Jenkins"', cwd=temp_dir, env=env)
        commit_msg = f"Initial commit {sit_branch} [skip ci]"
        run_cmd(f'git commit -m "{commit_msg}"', cwd=temp_dir, env=env)
        run_cmd(f"git push origin {sit_branch}", cwd=temp_dir, env=env)
        print(f"Branch '{sit_branch}' created and pushed successfully.", flush=True)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

if __name__ == "__main__":
    main()
