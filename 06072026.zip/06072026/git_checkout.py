#!/usr/bin/env python3
import os
import sys
import subprocess
import yaml
sys.stdout.reconfigure(line_buffering=True)

from pathlib import Path

def run_cmd(cmd, capture_output=False, check=True, env=None):
    result = subprocess.run(
        cmd,
        shell=True,
        capture_output=capture_output,
        text=True,
        env=env,
    )
    if check and result.returncode != 0:
        raise RuntimeError(f"Command failed (exit {result.returncode}): {cmd}\n{result.stderr}")
    return result.stdout.strip() if capture_output else None

def main():
    required_vars = ["BRANCH_NAME", "COMMIT_ID", "REPO_SSH_URL"]
    missing = [var for var in required_vars if var not in os.environ]
    if missing:
        sys.stderr.write(f"Missing required environment variables: {', '.join(missing)}\n")
        sys.exit(1)

    branch_name = os.environ["BRANCH_NAME"]
    commit_id   = os.environ["COMMIT_ID"]

    os.environ["CURRENT_STAGE"] = "Checkout"
    os.environ["GIT_COMMIT"] = commit_id
    os.environ["ACTUAL_BRANCH"] = branch_name
    os.environ["SIT_BRANCH"] = ""
    os.environ["RELEASE_NAME"] = ""
    os.environ["IN_RELEASE"] = "false"

    repo_dir = Path.cwd()
    print(f"Using existing repository at {repo_dir}", flush=True)
    try:
        current_commit = run_cmd("git rev-parse HEAD", capture_output=True)
        if current_commit != commit_id:
            print(f"Warning: current HEAD ({current_commit}) differs from expected COMMIT_ID ({commit_id})", flush=True)
    except Exception as e:
        print(f"Error verifying commit: {e}", flush=True)

    workspace_dir = Path(os.getenv('WORKSPACE', Path.cwd()))
    image_config_path = workspace_dir / "jenkins" / "image-config.yml"
    if not image_config_path.is_file():
        print(f"image-config.yml not found at {image_config_path}, skipping SIT detection", flush=True)
    else:
        with open(image_config_path) as f:
            cfg = yaml.safe_load(f)
        for sit_branch, branch_list in cfg.get("branches", {}).items():
            if branch_name in branch_list:
                os.environ["SIT_BRANCH"] = sit_branch
                # Correct: replace only leading 'sit_' prefix once
                # sit_20260520 → release_20260520
                # sit_sample_20260522 → release_sample_20260522
                os.environ["IN_RELEASE"] = "true"
                print(f"Branch '{branch_name}' is allowed for release: SIT='{sit_branch}'", flush=True)
                break
        else:
            print(f"Branch '{branch_name}' is not present in any SIT release.", flush=True)

    git_info = run_cmd(
        f"git show -s --format='%an|%ae|%cn|%cd|%h|%s' {commit_id}",
        capture_output=True,
    )
    author_name, author_email, committer_name, commit_date, short_sha, subject = git_info.split("|")
    os.environ["COMMIT_AUTHOR"] = f"{author_name} <{author_email}>"
    os.environ["COMMIT_DATE"] = commit_date
    os.environ["COMMIT_SHORT_SHA"] = short_sha
    os.environ["COMMIT_MESSAGE"] = subject

    summary = f"""
    ======== Commit Information ========
    Selected Release: {os.getenv('SIT_BRANCH')}
    ACTUAL_BRANCH   : {branch_name}
    Full Commit ID  : {commit_id}
    Short Commit ID : {short_sha}
    Author          : {author_name} <{author_email}>
    Committer       : {committer_name}
    Commit Date     : {commit_date}
    Message         : {subject}
    """.strip()
    print(summary, flush=True)

    print("Checkout stage completed successfully.", flush=True)

    # ── KEY=VALUE block — must be last output, no other lines after this ──
    # Jenkins readProperties captures these; any non KEY=VALUE line above is
    # treated as a comment and ignored by readProperties safely.
    sit_branch   = os.getenv('SIT_BRANCH', '')
    release_date = sit_branch.replace('sit_', '', 1) if sit_branch else ''
    # sit_20260520 → release_20260520  (replaces only the leading 'sit_')
    release_name = 'release_' + release_date if release_date else ''

    print(f"GIT_COMMIT={commit_id}", flush=True)
    print(f"ACTUAL_BRANCH={branch_name}", flush=True)
    print(f"SIT_BRANCH={sit_branch}", flush=True)
    print(f"IN_RELEASE={os.getenv('IN_RELEASE', 'false')}", flush=True)
    print(f"RELEASE_DATE={release_date}", flush=True)
    print(f"RELEASE_NAME={release_name}", flush=True)
    print(f"COMMIT_AUTHOR={os.getenv('COMMIT_AUTHOR', '')}", flush=True)
    print(f"COMMIT_DATE={os.getenv('COMMIT_DATE', '')}", flush=True)
    print(f"COMMIT_SHORT_SHA={os.getenv('COMMIT_SHORT_SHA', '')}", flush=True)
    print(f"COMMIT_MESSAGE={os.getenv('COMMIT_MESSAGE', '')}", flush=True)



if __name__ == "__main__":
    main()
