pipeline {
    agent { node { label 'bnpp-cdtools' } }

    triggers {
        GenericTrigger(
            genericVariables: [
                [key: 'BRANCH_NAME',    value: '$.changes[0].ref.displayId'],
                [key: 'COMMIT_ID',      value: '$.commits[0].id'],
                [key: 'COMMIT_MESSAGE', value: '$.commits[0].message']
            ],
            token                    : 'unisrc-jira-pipeline-token',
            regexpFilterText         : '$BRANCH_NAME $COMMIT_MESSAGE',
            regexpFilterExpression   : '^CZUNISRC-\\S+\\s(?!.*\\[skip ci\\]).*$',
            causeString              : 'Push to $BRANCH_NAME',
            printContributedVariables: true,
            printPostContent         : true
        )
    }

    environment {
        SONARQUBE_SERVER          = 'Sonar-unidata'
        SONARQUBE_PROJECT_KEY     = 'unidata.unisrc'
        SONARQUBE_PROJECT_NAME    = 'unidata.unisrc'
        SONARQUBE_PROJECT_VERSION = "1.0.${BUILD_NUMBER}"
        SONAR_HOST_URL            = 'https://sonarqube.cib.echonet'
        DISABLE_QUALITY_GATE      = 'true'

        BITBUCKET_API_URL         = 'https://bitbucket.cib.echonet'
        BITBUCKET_TOKEN           = credentials('bitbucket-pr-token')
        PROJECT_KEY               = 'UNIDATA'
        REPO_NAME                 = 'unisrc'
        REPO_SSH_URL              = 'ssh://git@bitbucket.cib.echonet:7999/unidata/unisrc.git'

        BUILD_SERVER              = 'BUILD'
        ARTI_REPO_DEV             = 'unidata-docker-local-dev'
        ARTI_REPO_PROD            = 'unidata-docker-local-release'
        ARTIFACTORY_REGISTRY      = 'artifactory.cib.echonet'
        DOCKER_REPO_PATH          = 'unisrc/testdockerimages'
        VERSION_SECTION           = 'jira'
        VERSION_FILE              = 'jenkins/version.yml'

        // Path prefix where all jira-stage Python scripts live in the repo
        PY_SCRIPTS                = 'jenkins/python_scripts/jira_stages'
    }

    stages {

        // ─────────────────────────────────────────────────────────────────
        // CHECKOUT  (must stay Groovy — requires GitSCM + stash)
        // Python script handles: commit metadata, image-config.yml branch
        // lookup → SIT_BRANCH / IN_RELEASE / RELEASE_NAME / RELEASE_DATE
        // ─────────────────────────────────────────────────────────────────
        stage('Checkout') {
            steps {
                script {
                    env.CURRENT_STAGE = 'Checkout'

                    // Use webhook-provided BRANCH_NAME (not hardcoded)
                    checkout([
                        $class: 'GitSCM',
                        branches: [[name: "*/${env.BRANCH_NAME}"]],
                        userRemoteConfigs: [[
                            credentialsId: 'SVC_Jenkins_Bitbucket_DEV',
                            url          : env.REPO_SSH_URL
                        ]]
                    ])

                    stash name: 'ansible-files', includes: 'ansible/, tools/, jenkins/'

                    // Ensure COMMIT_ID is set (from webhook or fallback to HEAD)
                    env.COMMIT_ID = env.COMMIT_ID ?: sh(script: 'git rev-parse HEAD', returnStdout: true).trim()

                    sh "chmod +x ${env.PY_SCRIPTS}/git_checkout.py"
                    def rawOutput = sh(
                        script: "python3 -u ${env.PY_SCRIPTS}/git_checkout.py 2>&1",
                        returnStdout: true
                    ).trim()
                    echo "=== git_checkout.py output ===\n${rawOutput}\n=== END ==="

                    // readProperties: interpolation:false prevents Groovy from
                    // trying to expand ${...} inside values (e.g. commit messages).
                    // Only lines matching KEY=VALUE are parsed; all other lines are
                    // treated as comments and safely ignored.
                    writeFile file: 'checkout_env.properties', text: rawOutput
                    def props = readProperties(
                        file             : 'checkout_env.properties',
                        interpolate      : false
                    )

                    env.GIT_COMMIT       = props.GIT_COMMIT       ?: env.COMMIT_ID
                    env.ACTUAL_BRANCH    = props.ACTUAL_BRANCH     ?: env.BRANCH_NAME
                    env.SIT_BRANCH       = props.SIT_BRANCH        ?: ''
                    env.IN_RELEASE       = props.IN_RELEASE        ?: 'false'
                    env.RELEASE_DATE     = props.RELEASE_DATE      ?: ''
                    env.RELEASE_NAME     = props.RELEASE_NAME      ?: ''
                    env.COMMIT_AUTHOR    = props.COMMIT_AUTHOR     ?: ''
                    env.COMMIT_DATE      = props.COMMIT_DATE       ?: ''
                    env.COMMIT_SHORT_SHA = props.COMMIT_SHORT_SHA  ?: ''
                    env.COMMIT_MESSAGE   = props.COMMIT_MESSAGE    ?: ''
                }
            }
        }

        // ─────────────────────────────────────────────────────────────────
        // SONARQUBE  (must stay Groovy — requires withSonarQubeEnv wrapper
        // which injects the auth token automatically; Python script handles
        // the actual sonar-scanner invocation inside the wrapper)
        // ─────────────────────────────────────────────────────────────────
        stage('SonarQube Analysis') {
            tools { jdk 'jdk-17.0.5-linux' }
            steps {
                withSonarQubeEnv("${SONARQUBE_SERVER}") {
                    script {
                        env.CURRENT_STAGE = 'SonarQube Analysis'
                        sh "chmod +x ${env.PY_SCRIPTS}/sonar_analysis.py"
                        sh "python3 -u ${env.PY_SCRIPTS}/sonar_analysis.py"
                        echo "SonarQube Analysis completed successfully."
                    }
                }
            }
        }


        // ─────────────────────────────────────────────────────────────────
        // Everything below is gated by IN_RELEASE == 'true'
        // ─────────────────────────────────────────────────────────────────
        stage('skip ci if the jira branch is not in releases') {
            when { expression { env.IN_RELEASE == 'true' } }
            stages {

                // ─────────────────────────────────────────────────────────
                // CREATE SIT BRANCH
                // Python script: checks Bitbucket API, creates branch if
                // absent.  SSH credentials injected via sshagent so the
                // script can git-push without handling keys directly.
                // ─────────────────────────────────────────────────────────
                stage('Create SIT Branch') {
                    steps {
                        script {
                            env.CURRENT_STAGE = 'Create SIT Branch'
                            sh "chmod +x ${env.PY_SCRIPTS}/create_sit_branch.py"
                            withCredentials([sshUserPrivateKey(
                                    credentialsId: 'SVC_Jenkins_Bitbucket_DEV',
                                    keyFileVariable: 'SSH_KEY')]) {
                                sshagent(credentials: ['SVC_Jenkins_Bitbucket_DEV']) {
                                    def output = sh(
                                        script: "python3 -u ${env.PY_SCRIPTS}/create_sit_branch.py 2>&1",
                                        returnStdout: true
                                    ).trim()
                                    echo "=== create_sit_branch.py output ===\n${output}\n=== END ==="
                                }
                // ─────────────────────────────────────────────────────────
                stage('Bitbucket PR for SIT branch') {
                    steps {
                        script {
                            env.CURRENT_STAGE = 'Bitbucket PR for SIT branch'
                            sh "chmod +x ${env.PY_SCRIPTS}/pr_creation_stage.py"
                            def output = sh(
                                script: "python3 -u ${env.PY_SCRIPTS}/pr_creation_stage.py 2>&1",
                                returnStdout: true
                            ).trim()
                            echo "=== pr_creation_stage.py output ===\n${output}\n=== END ==="

                            writeFile file: 'pr_env.properties', text: output
                            def props = readProperties(
                                file        : 'pr_env.properties',
                                interpolate : false
                            )
                            env.PR_ID = props.PR_ID ?: ''
                        }
                    }
                }

                // ─────────────────────────────────────────────────────────
                // APPROVAL  (must stay Groovy — Jenkins input() API)
                // Release name dropdown is built from image-config.yml
                // branches keys (sit_* → release_*).
                // ─────────────────────────────────────────────────────────
                stage('Approval - Build Docker Image?') {
                    steps {
                        script {
                            env.CURRENT_STAGE = 'Approval - Build Docker Image?'

                            def imageConfig = readYaml file: 'jenkins/image-config.yml'
                            def derivedName = env.RELEASE_NAME  // set in Checkout by git_checkout.py

                            // Build release name choices from sit_* branch keys
                            def configReleases = imageConfig?.branches
                                ? imageConfig.branches.keySet()
                                    .findAll { it.startsWith('sit_') }
                                    .collect  { it.replaceFirst('^sit_', 'release_') }
                                    .sort()
                                : []

                            // Derived name first so it is the default selection
                            def releaseChoices = ([derivedName] + configReleases.findAll { it != derivedName }).unique()

                            echo """
                                ── Release Name Selection ──
                                SIT Branch      : ${env.SIT_BRANCH}
                                Auto-derived    : ${derivedName}
                                All choices     : ${releaseChoices.join(', ')}
                            """.stripIndent()

                            def userInput = input(
                                message: "PR #${env.PR_ID ?: '<unknown>'} created. Build Docker image?",
                                parameters: [
                                    choice(name: 'BUILD_IMAGE',  choices: ['NO', 'YES'],
                                           description: 'Select YES to build & push Docker images'),
                                    choice(name: 'RELEASE_TYPE', choices: ['PATCH', 'MINOR', 'MAJOR'],
                                           description: 'Version bump type'),
                                    choice(name: 'RELEASE_NAME', choices: releaseChoices,
                                           description: "Release name for CD trigger. '${derivedName}' is auto-derived from branch.")
                                ]
                            )

                            env.BUILD_IMAGE  = userInput['BUILD_IMAGE']
                            env.RELEASE_TYPE = userInput['RELEASE_TYPE']
                            env.RELEASE_NAME = userInput['RELEASE_NAME']

                            if (env.RELEASE_NAME == derivedName) {
                                echo "RELEASE_NAME confirmed as auto-derived: ${env.RELEASE_NAME}"
                            } else {
                                echo "RELEASE_NAME overridden by operator: ${derivedName} → ${env.RELEASE_NAME}"
                            }

                            env.ARTI_REPO   = env.ARTI_REPO_DEV
                            env.DOCKER_REPO = "${DOCKER_REPO_PATH}/releases/${env.ACTUAL_BRANCH.toLowerCase()}"
                        }
                    }
                }

                // ─────────────────────────────────────────────────────────
                // DETECT CHANGED FILES  — fully Python
                // Groovy must write PREV_SUCCESSFUL_COMMIT and the
                // changeSets fallback before calling the script.
                // ─────────────────────────────────────────────────────────
                stage('Detect Changed Files') {
                    when { expression { env.BUILD_IMAGE == 'YES' } }
                    steps {
                        script {
                            env.CURRENT_STAGE = 'Detect Changed Files'

                            // Collect previous successful commit (Jenkins API — must be Groovy)
                            def prevCommit = ''
                            if (currentBuild.previousSuccessfulBuild) {
                                prevCommit = currentBuild.previousSuccessfulBuild
                                               .buildVariables?.GIT_COMMIT ?: ''
                            }
                            env.PREV_SUCCESSFUL_COMMIT = prevCommit

                            // Collect changeSets as fallback (Jenkins API — must be Groovy)
                            def fallbackFiles = []
                            def fallbackMeta  = []
                            if (!prevCommit) {
                                currentBuild.changeSets.each { cs ->
                                    cs.items.each { entry ->
                                        fallbackMeta << "${entry.commitId}|${entry.author}|${entry.msg}"
                                        entry.affectedFiles.each { f -> fallbackFiles << f.path }
                                    }
                                }
                            }
                            env.CHANGED_FILES_FALLBACK      = fallbackFiles.join(',')
                            env.CHANGED_FILES_FALLBACK_META = fallbackMeta.join('\n')

                            sh "chmod +x ${env.PY_SCRIPTS}/detect_changed_files.py"
                            echo "Detecting Changed Files"
                            def output = sh(
                                script: "python3 -u ${env.PY_SCRIPTS}/detect_changed_files.py 2>&1",
                                returnStdout: true
                            ).trim()
                            echo "=== detect_changed_files.py output ===\n${output}\n=== END ==="

                            writeFile file: 'detect_env.properties', text: output
                            def props = readProperties(
                                file        : 'detect_env.properties',
                                interpolate : false
                            )

                            env.CHANGED_FILES   = props.CHANGED_FILES   ?: ''
                            env.IMAGES_TO_BUILD = props.IMAGES_TO_BUILD ?: ''
                            env.SKIP_BUILD      = props.SKIP_BUILD      ?: 'true'

                            // Persist BUILD_<IMAGE> flags emitted by the script
                            def imageConfig = readYaml file: 'jenkins/image-config.yml'
                            imageConfig.images.keySet().each { imageName ->
                                def key = "BUILD_${imageName.toUpperCase()}"
                                env."${key}" = props."${key}" ?: 'NO'
                            }

                            echo "CHANGED_FILES   = ${env.CHANGED_FILES}"
                            echo "IMAGES_TO_BUILD = ${env.IMAGES_TO_BUILD}"
                            echo "SKIP_BUILD      = ${env.SKIP_BUILD}"
                        }
                    }
                }

                // ─────────────────────────────────────────────────────────
                // BUMP VERSIONS  — fully Python
                // ─────────────────────────────────────────────────────────
                stage('Bump Versions') {
                    when { expression { env.BUILD_IMAGE == 'YES' && env.SKIP_BUILD == 'false' } }
                    steps {
                        script {
                            env.CURRENT_STAGE = 'Bump Versions'
                            sh "chmod +x ${env.PY_SCRIPTS}/bump_versions.py"
                            def output = sh(
                                script: "python3 -u ${env.PY_SCRIPTS}/bump_versions.py 2>&1",
                                returnStdout: true
                            ).trim()
                            echo "=== bump_versions.py output ===\n${output}\n=== END ==="

                            writeFile file: 'bump_env.properties', text: output
                            def props = readProperties(
                                file        : 'bump_env.properties',
                                interpolate : false
                            )

                            env.IMAGE_TAGS = props.IMAGE_TAGS ?: ''

                            // Persist <IMAGE>_IMAGE_TAG per built image
                            def imageConfig = readYaml file: 'jenkins/image-config.yml'
                            imageConfig.images.keySet().each { imageName ->
                                def key = "${imageName.toUpperCase()}_IMAGE_TAG"
                                if (props."${key}") {
                                    env."${key}" = props."${key}"
                                }
                            }
                            echo "IMAGE_TAGS = ${env.IMAGE_TAGS}"
                        }
                    }
                }


                // ─────────────────────────────────────────────────────────
                // BUILD DOCKER IMAGES  (must stay Groovy — agent switching,
                // unstash, withCredentials, and Ansible sh invocation)
                // ─────────────────────────────────────────────────────────
                stage('Build Docker Images via Ansible') {
                    when { expression { env.BUILD_IMAGE == 'YES' && env.SKIP_BUILD == 'false' } }
                    agent { node { label 'bnpp-deploytools-amer' } }
                    steps {
                        unstash 'ansible-files'
                        withCredentials([
                            usernamePassword(credentialsId: 'docker_machine_svc_creds',
                                             usernameVariable: 'SSH_USER',   passwordVariable: 'SSH_PASS'),
                            usernamePassword(credentialsId: 'Artifactory_Creds',
                                             usernameVariable: 'ARTI_USER',  passwordVariable: 'ARTI_PASS'),
                            usernamePassword(credentialsId: 'artifactory_creds_curl',
                                             usernameVariable: 'ARTI_USER1', passwordVariable: 'ARTI_PASS1')
                        ]) {
                            script {
                                env.CURRENT_STAGE = 'Build Docker Images via Ansible'

                                // Build JSON image list for the Ansible playbook
                                def imageConfig  = readYaml file: 'jenkins/image-config.yml'
                                def dockerImages = env.IMAGES_TO_BUILD.split(',').findAll { it }.collect { imageName ->
                                    if (env."BUILD_${imageName.toUpperCase()}" != 'YES') return null
                                    def config = imageConfig.images[imageName]
                                    if (!config?.dockerfile) error "No dockerfile defined for image: ${imageName}"
                                    def tag = env."${imageName.toUpperCase()}_IMAGE_TAG"
                                    if (!tag) error "No image tag for image: ${imageName}"
                                    return [name: imageName, dockerfile: config.dockerfile, tag: tag]
                                }.findAll { it }

                                if (dockerImages.isEmpty()) error "No docker images selected for build"
                                env.DOCKER_IMAGES = groovy.json.JsonOutput.toJson(dockerImages)
                                echo "Docker Images Payload: ${env.DOCKER_IMAGES}"

                                dir('ansible') {
                                    sh '''
                                    ansible-playbook -i ./inventory/hosts.ini ./playbooks/build_images.yml \
                                        -e "docker_images=$DOCKER_IMAGES" \
                                        -e "build_server=$BUILD_SERVER" \
                                        -e "ansible_user=$SSH_USER" \
                                        -e "ansible_password=$SSH_PASS" \
                                        -e "ansible_ssh_extra_args='-o PreferredAuthentications=password -o PubkeyAuthentication=no -o StrictHostKeyChecking=no'" \
                                        -e "docker_repo=$DOCKER_REPO" \
                                        -e "arti_repo=$ARTI_REPO" \
                                        -e "git_repo=$REPO_SSH_URL" \
                                        -e "git_branch=$ACTUAL_BRANCH" \
                                        -e "artifactory_user=$ARTI_USER" \
                                        -e "artifactory_password=$ARTI_PASS" \
                                        -e "artifactory_password_curl=$ARTI_PASS1" \
                                        -v
                                    '''
                                }
                            }
                        }
                    }
                }

                // ─────────────────────────────────────────────────────────
                // PUSH IMAGES  (must stay Groovy — agent switching,
                // unstash, withCredentials, Ansible sh invocation)
                // ─────────────────────────────────────────────────────────
                stage('Push Images to Artifactory') {
                    when { expression { env.BUILD_IMAGE == 'YES' && env.SKIP_BUILD == 'false' } }
                    agent { node { label 'bnpp-deploytools-amer' } }
                    steps {
                        unstash 'ansible-files'
                        withCredentials([
                            usernamePassword(credentialsId: 'docker_machine_svc_creds',
                                             usernameVariable: 'SSH_USER', passwordVariable: 'SSH_PASS')
                        ]) {
                            dir('ansible') {
                                script {
                                    env.CURRENT_STAGE = 'Push Images to Artifactory'
                                    def imagesToPush = env.IMAGES_TO_BUILD.split(',').findAll { imageName ->
                                        imageName && env."BUILD_${imageName.toUpperCase()}" == 'YES'
                                    }
                                    if (imagesToPush.isEmpty()) { echo "No images to push"; return }

                                    imagesToPush.each { imageName ->
                                        def imageTag = env."${imageName.toUpperCase()}_IMAGE_TAG"
                                        if (!imageTag) error "No image tag for: ${imageName}"
                                        echo "Pushing ${imageName}:${imageTag}..."
                                        sh """
                                        ansible-playbook -i ./inventory/hosts.ini ./playbooks/push_to_artifactory.yml \
                                            -e "ansible_user=$SSH_USER" \
                                            -e "ansible_password=$SSH_PASS" \
                                            -e "artifactory_registry=$ARTIFACTORY_REGISTRY" \
                                            -e "ansible_ssh_extra_args='-o PreferredAuthentications=password -o PubkeyAuthentication=no -o StrictHostKeyChecking=no'" \
                                            -e "arti_repo=$ARTI_REPO" \
                                            -e "build_server=$BUILD_SERVER" \
                                            -e "docker_repo=$DOCKER_REPO" \
                                            -e "image_name=${imageName}" \
                                            -e "image_tag=${imageTag}" \
                                            -v
                                        """
                                    }
                                }
                            }
                        }
                    }
                }

                // ─────────────────────────────────────────────────────────
                // UPDATE YAML + GIT PUSH  — fully Python
                // withCredentials injects SSH_KEY; the Python script uses
                // GIT_SSH_COMMAND=ssh -i $SSH_KEY for all git operations.
                // ─────────────────────────────────────────────────────────
                stage('Update YAML Files And Push Changes') {
                    when { expression { env.BUILD_IMAGE == 'YES' && env.SKIP_BUILD == 'false' } }
                    steps {
                        withCredentials([
                            sshUserPrivateKey(credentialsId: 'SVC_Jenkins_Bitbucket_DEV',
                                              keyFileVariable: 'SSH_KEY')
                        ]) {
                            script {
                                env.CURRENT_STAGE = 'Update YAML Files And Push Changes'
                                sh "chmod +x ${env.PY_SCRIPTS}/update_yaml_push.py"
                                def output = sh(
                                    script: "python3 -u ${env.PY_SCRIPTS}/update_yaml_push.py 2>&1",
                                    returnStdout: true
                                ).trim()
                                echo "=== update_yaml_push.py output ===\n${output}\n=== END ==="

                                writeFile file: 'yaml_push_env.properties', text: output
                                def props = readProperties(
                                    file        : 'yaml_push_env.properties',
                                    interpolate : false
                                )
                                env.YAML_PUSH_STATUS = props.YAML_PUSH_STATUS ?: 'unknown'
                                echo "YAML_PUSH_STATUS = ${env.YAML_PUSH_STATUS}"
                            }
                        }
                    }
                }

                // ─────────────────────────────────────────────────────────
                // APPROVAL DEPLOY  (must stay Groovy — Jenkins input() API)
                // ─────────────────────────────────────────────────────────
                stage('Approval - For Deployment in server?') {
                    steps {
                        script {
                            env.CURRENT_STAGE = 'Approval - For Deployment in server?'
                            def userInput = input(
                                message: "PR #${env.PR_ID ?: '<unknown>'} — images built and pushed. Deploy?",
                                parameters: [
                                    choice(name: 'DEPLOY', choices: ['NO', 'YES'],
                                           description: 'Select YES to trigger CD pipeline'),
                                    choice(name: 'ENV',    choices: ['DEV1', 'DEV2'],
                                           description: 'Target environment')
                                ]
                            )
                            env.DEPLOY     = userInput['DEPLOY']
                            env.TARGET_ENV = userInput['ENV']
                        }
                    }
                }

                // ─────────────────────────────────────────────────────────
                // TRIGGER CD  (must stay Groovy — Jenkins build() API)
                // ─────────────────────────────────────────────────────────
                stage('Trigger CD pipeline') {
                    when { expression { env.DEPLOY == 'YES' } }
                    steps {
                        script {
                            env.CURRENT_STAGE = 'Trigger CD pipeline'
                            build job: 'CD_pipeline',
                                parameters: [
                                    string(name: 'TARGET_ENV',   value: env.TARGET_ENV),
                                    string(name: 'BRANCH_NAME',  value: env.ACTUAL_BRANCH),
                                    string(name: 'RELEASE_NAME', value: env.RELEASE_NAME),
                                    string(name: 'IMAGE_TAGS',   value: env.IMAGE_TAGS ?: '')
                                ]
                        }
                    }
                }

            } // end inner stages
        } // end skip-ci gate

    } // end stages

    // ─────────────────────────────────────────────────────────────────────
    // POST  (must stay Groovy — mail() and cleanWs() are Jenkins steps)
    // ─────────────────────────────────────────────────────────────────────
    post {
        success {
            script {
                def APPROVERS = [
                    [id: 'j21346', email: 'haritha.murugan@ext.asia.bnpparibas.com'],
                    [id: 'j25075', email: 'puneethkumar.bhojanapu@ext.asia.bnpparibas.com'],
                ]
                def sonarUrl = "${env.SONAR_HOST_URL}/dashboard?id=${env.SONARQUBE_PROJECT_KEY}&branch=${env.ACTUAL_BRANCH}"
                mail(
                    to     : APPROVERS.collect { it.email }.join(','),
                    subject: "[SUCCESS] Jira CI Pipeline — ${env.JOB_NAME} | Build #${env.BUILD_NUMBER}",
                    body   : """\
CI Jira Pipeline SUCCEEDED ✅

---------------------------------------------------------------
  Job Name      : ${env.JOB_NAME}
  Build Number  : #${env.BUILD_NUMBER}
  Pipeline URL  : ${env.BUILD_URL}consoleFull
---------------------------------------------------------------

COMMIT DETAILS
  Branch        : ${env.ACTUAL_BRANCH}
  Commit ID     : ${env.GIT_COMMIT} (${env.COMMIT_SHORT_SHA})
  Author        : ${env.COMMIT_AUTHOR}
  Commit Date   : ${env.COMMIT_DATE}
  Message       : ${env.COMMIT_MESSAGE}

RELEASE CONTEXT
  SIT Branch    : ${env.SIT_BRANCH ?: '(not in release)'}
  Release Date  : ${env.RELEASE_DATE ?: '(none)'}
  In Release    : ${env.IN_RELEASE}
  PR ID         : ${env.PR_ID ? '#' + env.PR_ID : '(none)'}

BUILD RESULTS
  Build Image   : ${env.BUILD_IMAGE ?: 'NO'}
  Release Type  : ${env.RELEASE_TYPE ?: '(none)'}
  Images Built  : ${env.IMAGE_TAGS ?: '(none — build skipped or no changes detected)'}
  Deploy To     : ${env.TARGET_ENV ?: '(not triggered)'}

SONARQUBE ANALYSIS
  Project       : ${env.SONARQUBE_PROJECT_NAME} v${env.SONARQUBE_PROJECT_VERSION}
  Results URL   : ${sonarUrl}
---------------------------------------------------------------
This is an automated notification from Jenkins CI Jira Pipeline.
""".stripIndent()
                )
            }
        }

        failure {
            script {
                def APPROVERS = [
                    [id: 'j25075', email: 'puneethkumar.bhojanapu@ext.asia.bnpparibas.com'],
                ]
                def sonarUrl = "${env.SONAR_HOST_URL}/dashboard?id=${env.SONARQUBE_PROJECT_KEY}&branch=${env.ACTUAL_BRANCH}"
                def failedStage = env.CURRENT_STAGE ?: 'Unknown (pipeline may have failed before first stage)'

                def recoveryAction = [
                    'Checkout'                              : 'Check Bitbucket connectivity and branch name, then re-run.',
                    'SonarQube Analysis'                    : 'Check SonarQube server connectivity and project config, then re-run.',
                    'Create SIT Branch'                     : 'Check Bitbucket credentials and repo access, then re-run.',
                    'Bitbucket PR for SIT branch'           : 'Check Bitbucket API credentials and existing PR state, then re-run.',
                    'Approval - Build Docker Image?'        : 'Re-run when ready to approve.',
                    'Detect Changed Files'                  : 'Check image-config.yml for missing triggers, then re-run.',
                    'Bump Versions'                         : 'version.yml was NOT pushed. Re-run is safe.',
                    'Build Docker Images via Ansible'       : '⚠️ Docker build may have partially completed. Check the build server and re-run.',
                    'Push Images to Artifactory'            : '⚠️ Some images may already be pushed. Verify Artifactory before re-running.',
                    'Update YAML Files And Push Changes'    : 'YAML/version.yml may be partially updated. Check git diff on the Jira branch, then re-run.',
                    'Approval - For Deployment in server?'  : 'Re-run when ready to approve deployment.',
                    'Trigger CD pipeline'                   : 'CD pipeline trigger failed. Check CD_pipeline job and re-trigger manually if needed.',
                ].get(failedStage, 'Check the pipeline logs for details and assess the system state before re-running.')

                mail(
                    to     : APPROVERS.collect { it.email }.join(','),
                    subject: "[FAILED] Jira CI Pipeline — ${env.JOB_NAME} | Build #${env.BUILD_NUMBER}",
                    body   : """\
CI Jira Pipeline FAILED ❌ !!!

---------------------------------------------------------------
  Job Name      : ${env.JOB_NAME}
  Build Number  : #${env.BUILD_NUMBER}
  Pipeline URL  : ${env.BUILD_URL}consoleFull
  Failed Stage  : ${failedStage}
---------------------------------------------------------------

COMMIT DETAILS
  Branch        : ${env.ACTUAL_BRANCH ?: '(checkout may have failed)'}
  Commit ID     : ${env.GIT_COMMIT ?: '(unknown)'} (${env.COMMIT_SHORT_SHA ?: '?'})
  Author        : ${env.COMMIT_AUTHOR ?: '(unknown)'}
  Commit Date   : ${env.COMMIT_DATE ?: '(unknown)'}
  Message       : ${env.COMMIT_MESSAGE ?: '(unknown)'}

RELEASE CONTEXT
  SIT Branch    : ${env.SIT_BRANCH ?: '(not in release)'}
  Release Date  : ${env.RELEASE_DATE ?: '(none)'}
  In Release    : ${env.IN_RELEASE ?: 'false'}
  PR ID         : ${env.PR_ID ? '#' + env.PR_ID : '(none)'}

BUILD RESULTS
  Build Image   : ${env.BUILD_IMAGE ?: 'NO'}
  Release Type  : ${env.RELEASE_TYPE ?: '(none)'}
  Images Built  : ${env.IMAGE_TAGS ?: '(none — build skipped, failed, or no changes)'}
  Deploy To     : ${env.TARGET_ENV ?: '(not triggered)'}

SONARQUBE ANALYSIS
  Project       : ${env.SONARQUBE_PROJECT_NAME} v${env.SONARQUBE_PROJECT_VERSION}
  Results URL   : ${sonarUrl}
  (Check SonarQube — analysis may or may not have completed before the failure)

RECOVERY ACTION:
${recoveryAction}
---------------------------------------------------------------
Check the full pipeline logs for failure details.
---------------------------------------------------------------
This is an automated notification from Jenkins CI Jira Pipeline.
""".stripIndent()
                )
            }
        }

        always { cleanWs() }
    }
}
